import asyncio
import platform

import pygame
from pygame import mixer

is_web = platform.system() == "Emscripten"
if is_web:
    from platform import window


def save_highscore(score: int) -> None:
    if is_web:
        window.localStorage.setItem("pop_cat_highscore", str(score))
    else:
        with open("poptimes.txt", "w", encoding="utf-8") as f:
            f.write(str(score))


def load_highscore() -> int:
    if is_web:
        res = window.localStorage.getItem("pop_cat_highscore")
        return int(res) if res else 0
    try:
        with open("poptimes.txt", "r", encoding="utf-8") as f:
            return int(f.read())
    except Exception:
        return 0


async def main() -> None:
    pygame.init()
    mixer.init()
    mixer.music.load("pop-cat.ogg")

    gw, gh = 800, 600
    clock = pygame.time.Clock()
    screen = pygame.display.set_mode((gw, gh))
    pygame.display.set_caption("pop-cat")

    # Default font works under pygame-web; system CJK fonts do not.
    gamefont = pygame.font.Font(None, 64)

    click_image = pygame.image.load("images/popcat-open.png").convert()
    unclick_image = pygame.image.load("images/popcat.png").convert()
    bg_image = unclick_image

    point = load_highscore()
    run = True

    while run:
        clock.tick(60)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
            elif event.type in (pygame.KEYDOWN, pygame.MOUSEBUTTONDOWN):
                bg_image = click_image
                point += 1
                mixer.music.play()
            elif event.type in (pygame.KEYUP, pygame.MOUSEBUTTONUP):
                bg_image = unclick_image

        scaled = pygame.transform.scale(bg_image, (gw, gh))
        screen.blit(scaled, (0, 0))
        text = gamefont.render(str(point), True, (0, 0, 0), (255, 255, 255))
        screen.blit(text, (50, gh - 100))
        pygame.display.update()
        save_highscore(point)
        await asyncio.sleep(0)

    pygame.quit()


asyncio.run(main())

"""Recolor each season car: most pixels get the team's main color, then crop."""
from collections import Counter
from pathlib import Path

from PIL import Image

from liveries import palette_for
from seasons import SEASONS, car_sprite_id

ASSETS = Path(__file__).resolve().parent / "assets"
BG = (186, 254, 202, 255)
BLACK = (0, 0, 0, 255)
WHITE = (255, 255, 255, 255)
YELLOW = (240, 250, 6, 255)
CROP = (1, 1, 21, 37)


def is_bg(c):
  r, g, b, a = c
  if a < 16:
    return True
  return abs(r - 186) < 22 and abs(g - 254) < 22 and abs(b - 202) < 22 and g > r and g > b


def sat(c):
  r, g, b = c[:3]
  mx, mn = max(r, g, b), min(r, g, b)
  return 0 if mx == 0 else (mx - mn) / mx


def is_yellow_light(c):
  r, g, b, a = c
  return a >= 16 and r > 160 and g > 160 and b < 90


def is_blackish(c):
  return max(c[:3]) < 38 and sat(c) < 0.35


def is_whiteish(c):
  r, g, b = c[:3]
  return min(r, g, b) > 232 and sat(c) < 0.12


def family(c):
  """Group similar paint into one family so counts keep priority."""
  r, g, b = c[:3]
  mx, mn = max(r, g, b), min(r, g, b)
  if mx == 0 or (mx - mn) / mx < 0.18:
    return "gray"
  if r >= g and r >= b:
    if g > b + 35 and g > 90:
      return "yellow"
    return "red"
  if g >= r and g >= b:
    return "green"
  return "blue"


def template_stem(spec):
  car = spec["car"]
  if car == "B194":
    return "MCL40"
  return car


def remap(im, pal):
  src = list(im.getdata())
  fam_counts = Counter()
  fam_vals = {}
  for c in src:
    if is_bg(c) or is_yellow_light(c) or is_blackish(c) or is_whiteish(c):
      continue
    fam = family(c)
    fam_counts[fam] += 1
    fam_vals.setdefault(fam, []).append(max(c[:3]))
  ranked = [f for f, _n in fam_counts.most_common()]
  main_fam = ranked[0] if ranked else None
  side_fam = ranked[1] if len(ranked) > 1 else None
  if main_fam:
    vals = fam_vals[main_fam]
    lo, hi = min(vals), max(vals)
  else:
    lo, hi = 0, 255
  dest = []
  for c in src:
    if is_bg(c):
      dest.append(BG)
      continue
    if is_yellow_light(c):
      dest.append(YELLOW)
      continue
    if is_blackish(c):
      dest.append(BLACK)
      continue
    if is_whiteish(c):
      dest.append(WHITE)
      continue
    fam = family(c)
    if fam == "gray":
      L = sum(c[:3]) / 3
      if L < 70:
        dest.append(BLACK)
      elif L > 200:
        dest.append(WHITE)
      else:
        dest.append((*pal["gray"], 255))
      continue
    if fam == main_fam:
      v = max(c[:3])
      if hi - lo < 8:
        dest.append((*pal["main"], 255))
      else:
        t = (v - lo) / (hi - lo)
        if t < 0.34:
          dest.append((*pal["dark"], 255))
        elif t > 0.67:
          dest.append((*pal["light"], 255))
        else:
          dest.append((*pal["main"], 255))
      continue
    if fam == side_fam and pal["side"]:
      frac = pal.get("side_frac", 1.0)
      if frac < 1.0:
        svals = fam_vals[side_fam]
        slo, shi = min(svals), max(svals)
        v = max(c[:3])
        t = 0 if shi == slo else (v - slo) / (shi - slo)
        if t >= (1.0 - frac):
          dest.append((*pal["side"], 255))
        else:
          dest.append((*pal["light"], 255))
      else:
        dest.append((*pal["side"], 255))
      continue
    if pal["side"] and fam != main_fam:
      dest.append((*pal["side"], 255))
      continue
    dest.append((*pal["dark"], 255))
  out = Image.new("RGBA", im.size)
  out.putdata(dest)
  p = out.load()
  s = im.load()
  for y in range(im.size[1]):
    for x in range(im.size[0]):
      if is_bg(s[x, y]):
        p[x, y] = BG
  return out


def main():
  cache = {}
  written = 0
  for year, teams in SEASONS.items():
    for spec in teams:
      stem = template_stem(spec)
      if stem not in cache:
        path = ASSETS / ("%s.png" % stem)
        im = Image.open(path).convert("RGBA")
        if im.size != (22, 38):
          raise SystemExit("template %s is %s, want 22x38" % (stem, im.size))
        cache[stem] = im
      pal = palette_for(year, spec["name"], spec["color"])
      painted = remap(cache[stem], pal)
      cropped = painted.crop(CROP)
      if cropped.size != (20, 36):
        raise SystemExit("crop %s" % (cropped.size,))
      out_name = car_sprite_id(year, spec["name"])
      cropped.save(ASSETS / ("%s.png" % out_name))
      written += 1
  print("wrote", written, "20x36 sprites")


if __name__ == "__main__":
  main()

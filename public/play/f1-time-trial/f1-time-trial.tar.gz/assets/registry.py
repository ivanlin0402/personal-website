from settings import *
from engine import Engine
from team import Team
from driver import Driver
from car import Car

def RegistryINIT():
  class ENGINE:
    V8 = Engine("V8", 30, 50, 0.19)
    V10 = Engine("V10", 29, 46, 0.21)

  class TEAM:
    REDBULL = Team("Red Bull Racing")
    FERRARI = Team("Ferrari")
    MERCEDES = Team("Mercedes")
    MCLAREN = Team("McLaren")
    AUDI = Team("Audi")
    HAAS = Team("Haas")
    WILLIAMS = Team("Williams")
    ALPINE = Team("Alpine")
    ASTONMARTIN = Team("Aston Martin")
    RACINGBULLS = Team("Racing Bulls")

    TEAMS = [REDBULL, FERRARI, MERCEDES, MCLAREN, AUDI, HAAS, WILLIAMS, ALPINE, ASTONMARTIN, RACINGBULLS]

  class DRIVER:
    MAXVERSTAPPEN = Driver("Max Verstappen", 96, 100)
    ISSAKHADJAR = Driver("Issak Hadjar", 70, 70)
    CHARLESLECLERC = Driver("Charles Leclerc", 93, 80)
    LEWISHAMILTON = Driver("Lewis Hamilton", 90, 100)
    GEORGERUSSELL = Driver("George Russell", 92, 80)
    KIMIANTONELLI = Driver("Kimi Antonelli", 86, 80)
    LANDONORRIS = Driver("Lando Norris", 91, 80)
    OSCARPIASTRI = Driver("Oscar Piastri", 89, 80)
    NICOHULKENBERG = Driver("Nico Hulkenberg", 81, 80)
    GABRIELBORTOLETO = Driver("Gabriel Bortoleto", 74, 80)
    ESTEBANOCON = Driver("Esteban Ocon", 78, 80)
    OLIVERBEARMAN = Driver("Oliver Bearman", 80, 80)
    ALEXALBON = Driver("Alex Albon", 80, 80)
    CARLOSSAINZ = Driver("Carlos Sainz", 88, 80)
    PIERREGASLY = Driver("Pierre Gasly", 70, 80)
    FRANCOCOLAPINTO = Driver("Franco Colapinto", 64, 80)
    FERNANDOALONSO = Driver("Fernando Alonso", 78, 80)
    LANCESTROLL = Driver("Lance Stroll", 62, 80)
    LIAMLAWSON = Driver("Liam Lawson", 80, 80)
    ARVIDLINDBLAD = Driver("Arvid Lindblad", 80, 80)

    DRIVERS = [MAXVERSTAPPEN, ISSAKHADJAR, CHARLESLECLERC, LEWISHAMILTON,
               GEORGERUSSELL, KIMIANTONELLI, LANDONORRIS, OSCARPIASTRI,
               NICOHULKENBERG, GABRIELBORTOLETO, ESTEBANOCON, OLIVERBEARMAN,
               ALEXALBON, CARLOSSAINZ, PIERREGASLY, FRANCOCOLAPINTO,
               FERNANDOALONSO, LANCESTROLL, LIAMLAWSON, ARVIDLINDBLAD]

  count = 0
  for t in TEAM.TEAMS:
    t.AddDriver(DRIVER.DRIVERS[count])
    t.AddDriver(DRIVER.DRIVERS[count+1])
    count += 2

  rb20_01 = Car((3300, 4000), "RB20", ENGINE.V8)
  rb20_01.PartSetup("medium", 28, 25)
  rb20_01.AddDriver(DRIVER.MAXVERSTAPPEN)
  TEAM.REDBULL.AddCar(rb20_01)
  rb20_02 = Car((3300, 4000), "RB20", ENGINE.V8)
  rb20_02.PartSetup("medium", 28, 25)
  rb20_02.AddDriver(DRIVER.ISSAKHADJAR)
  TEAM.REDBULL.AddCar(rb20_02)


  sf26_01 = Car((3300, 4000), "SF26", ENGINE.V10)
  sf26_01.PartSetup("medium", 28, 25)
  sf26_01.AddDriver(DRIVER.CHARLESLECLERC)
  TEAM.FERRARI.AddCar(sf26_01)
  sf26_02 = Car((3300, 4000), "SF26", ENGINE.V10)
  sf26_02.PartSetup("medium", 28, 25)
  sf26_02.AddDriver(DRIVER.LEWISHAMILTON)
  TEAM.FERRARI.AddCar(sf26_02)

  w17_01 = Car((3300, 4000), "W17", ENGINE.V8)
  w17_01.PartSetup("medium", 28, 25)
  w17_01.AddDriver(DRIVER.GEORGERUSSELL)
  TEAM.MERCEDES.AddCar(w17_01)
  w17_02 = Car((3300, 4000), "W17", ENGINE.V8)
  w17_02.PartSetup("medium", 28, 25)
  w17_02.AddDriver(DRIVER.KIMIANTONELLI)
  TEAM.MERCEDES.AddCar(w17_02)

  mcl40_01 = Car((3300, 4000), "MCL40", ENGINE.V10)
  mcl40_01.PartSetup("medium", 28, 25)
  mcl40_01.AddDriver(DRIVER.LANDONORRIS)
  TEAM.MCLAREN.AddCar(mcl40_01)
  mcl40_02 = Car((3300, 4000), "MCL40", ENGINE.V10)
  mcl40_02.PartSetup("medium", 28, 25)
  mcl40_02.AddDriver(DRIVER.OSCARPIASTRI)
  TEAM.MCLAREN.AddCar(mcl40_02)

  r26_01 = Car((3300, 4000), "R26", ENGINE.V8)
  r26_01.PartSetup("medium", 28, 25)
  r26_01.AddDriver(DRIVER.NICOHULKENBERG)
  TEAM.AUDI.AddCar(r26_01)
  r26_02 = Car((3300, 4000), "R26", ENGINE.V8)
  r26_02.PartSetup("medium", 28, 25)
  r26_02.AddDriver(DRIVER.GABRIELBORTOLETO)
  TEAM.AUDI.AddCar(r26_02)

  vf26_01 = Car((3300, 4000), "VF26", ENGINE.V10)
  vf26_01.PartSetup("medium", 28, 25)
  vf26_01.AddDriver(DRIVER.ESTEBANOCON)
  TEAM.HAAS.AddCar(vf26_01)
  vf26_02 = Car((3300, 4000), "VF26", ENGINE.V10)
  vf26_02.PartSetup("medium", 28, 25)
  vf26_02.AddDriver(DRIVER.OLIVERBEARMAN)
  TEAM.HAAS.AddCar(vf26_02)

  fw48_01 = Car((3300, 4000), "FW48", ENGINE.V8)
  fw48_01.PartSetup("medium", 28, 25)
  fw48_01.AddDriver(DRIVER.ALEXALBON)
  TEAM.WILLIAMS.AddCar(fw48_01)
  fw48_02 = Car((3300, 4000), "FW48", ENGINE.V8)
  fw48_02.PartSetup("medium", 28, 25)
  fw48_02.AddDriver(DRIVER.CARLOSSAINZ)
  TEAM.WILLIAMS.AddCar(fw48_02)

  a526_01 = Car((3300, 4000), "A526", ENGINE.V10)
  a526_01.PartSetup("medium", 28, 25)
  a526_01.AddDriver(DRIVER.PIERREGASLY)
  TEAM.ALPINE.AddCar(a526_01)
  a526_02 = Car((3300, 4000), "A526", ENGINE.V10)
  a526_02.PartSetup("medium", 28, 25)
  a526_02.AddDriver(DRIVER.FRANCOCOLAPINTO)
  TEAM.ALPINE.AddCar(a526_02)

  amr26_01 = Car((3300, 4000), "AMR26", ENGINE.V10)
  amr26_01.PartSetup("medium", 28, 25)
  amr26_01.AddDriver(DRIVER.FERNANDOALONSO)
  TEAM.ASTONMARTIN.AddCar(amr26_01)
  amr26_02 = Car((3300, 4000), "AMR26", ENGINE.V10)
  amr26_02.PartSetup("medium", 28, 25)
  amr26_02.AddDriver(DRIVER.LANCESTROLL)
  TEAM.ASTONMARTIN.AddCar(amr26_02)

  vcarb03_01 = Car((3300, 4000), "VCARB03", ENGINE.V8)
  vcarb03_01.PartSetup("medium", 28, 25)
  vcarb03_01.AddDriver(DRIVER.LIAMLAWSON)
  TEAM.RACINGBULLS.AddCar(vcarb03_01)
  vcarb03_02 = Car((3300, 4000), "VCARB03", ENGINE.V8)
  vcarb03_02.PartSetup("medium", 28, 25)
  vcarb03_02.AddDriver(DRIVER.ARVIDLINDBLAD)
  TEAM.RACINGBULLS.AddCar(vcarb03_02)

  return ENGINE, TEAM, DRIVER

    

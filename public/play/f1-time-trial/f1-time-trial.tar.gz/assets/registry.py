from settings import *
from engine import Engine
from team import Team
from driver import Driver


# car_model, engine_name for each team (cars are created lazily after menu)
TEAM_SPECS = [
  ("Red Bull Racing", "RB20", "V8"),
  ("Ferrari", "SF26", "V10"),
  ("Mercedes", "W17", "V8"),
  ("McLaren", "MCL40", "V10"),
  ("Audi", "R26", "V8"),
  ("Haas", "VF26", "V10"),
  ("Williams", "FW48", "V8"),
  ("Alpine", "A526", "V10"),
  ("Aston Martin", "AMR26", "V10"),
  ("Racing Bulls", "VCARB03", "V8"),
]

DRIVER_SPECS = [
  ("Max Verstappen", 96, 100),
  ("Issak Hadjar", 70, 70),
  ("Charles Leclerc", 93, 80),
  ("Lewis Hamilton", 90, 100),
  ("George Russell", 92, 80),
  ("Kimi Antonelli", 86, 80),
  ("Lando Norris", 91, 80),
  ("Oscar Piastri", 89, 80),
  ("Nico Hulkenberg", 81, 80),
  ("Gabriel Bortoleto", 74, 80),
  ("Esteban Ocon", 78, 80),
  ("Oliver Bearman", 80, 80),
  ("Alex Albon", 80, 80),
  ("Carlos Sainz", 88, 80),
  ("Pierre Gasly", 70, 80),
  ("Franco Colapinto", 64, 80),
  ("Fernando Alonso", 78, 80),
  ("Lance Stroll", 62, 80),
  ("Liam Lawson", 80, 80),
  ("Arvid Lindblad", 80, 80),
]


def RegistryINIT():
  engines = {
    "V8": Engine("V8", 30, 50, 0.19),
    "V10": Engine("V10", 29, 46, 0.21),
  }

  drivers = [Driver(name, pace, tire) for name, pace, tire in DRIVER_SPECS]
  teams = []
  for i, (team_name, car_model, engine_name) in enumerate(TEAM_SPECS):
    team = Team(team_name)
    team.car_model = car_model
    team.engine_name = engine_name
    d1 = drivers[i * 2]
    d2 = drivers[i * 2 + 1]
    team.AddDriver(d1)
    team.AddDriver(d2)
    teams.append(team)

  class TEAM:
    TEAMS = teams

  class DRIVER:
    DRIVERS = drivers

  class ENGINE:
    BY_NAME = engines

  return ENGINE, TEAM, DRIVER

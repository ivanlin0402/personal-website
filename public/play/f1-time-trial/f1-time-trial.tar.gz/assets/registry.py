from settings import *
from engine import Engine
from team import Team
from driver import Driver
from seasons import get_season, car_sprite_id
from liveries import menu_color


def RegistryINIT(year=2025):
  year, season = get_season(year)

  engines = {
    "V8": Engine("V8", 30, 50, 0.19),
    "V10": Engine("V10", 29, 46, 0.21),
  }

  drivers = []
  teams = []
  for spec in season:
    team = Team(spec["name"])
    team.year = year
    team.short_name = spec["short"]
    team.color = menu_color(year, spec["name"], spec["color"])
    team.car_model = car_sprite_id(year, spec["name"])
    team.engine_name = spec["engine"]
    for name, pace, tire in spec["drivers"]:
      driver = Driver(name, pace, tire)
      team.AddDriver(driver)
      drivers.append(driver)
    teams.append(team)

  class TEAM:
    TEAMS = teams

  class DRIVER:
    DRIVERS = drivers

  class ENGINE:
    BY_NAME = engines

  return ENGINE, TEAM, DRIVER

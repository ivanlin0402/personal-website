from settings import *

class Text:
  def __init__(self, pos, word, size, color):
    self.pos = pos
    self.color = color
    self.font = pygame.font.Font("assets/font/Minecraftia-Regular.ttf", size)
    self.word = word
  def Draw(self, screen):
    self.text_surface = self.font.render(str(self.word), True, self.color)
    screen.blit(self.text_surface, self.pos)
  def Update(self, word):
    self.word = word
    if type(self.word) == float:
      self.word = "{:.2f}" . format(self.word)
    elif self.word == 0:
      self.word = "0.00"

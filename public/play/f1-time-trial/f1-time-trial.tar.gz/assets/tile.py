from settings import *

# Shared surfaces — one per tile type (avoids ~1GB of duplicate Surfaces on web)
_TILE_SURFACES = {}


def _tile_surface(tile_type):
  surf = _TILE_SURFACES.get(tile_type)
  if surf is not None:
    return surf
  surf = pygame.Surface((TILE_SIZE, TILE_SIZE))
  if tile_type == "grass":
    surf.fill(GREEN)
  elif tile_type == "road":
    surf.fill(GRAY)
  elif tile_type == "wall":
    surf.fill(BLACK)
  elif tile_type == "drs":
    surf.fill(YELLOW)
  else:
    surf.fill(GRAY)
  _TILE_SURFACES[tile_type] = surf
  return surf


class Tile(pygame.sprite.Sprite):
  def __init__(self, pos, tile_type, *groups):
    super().__init__(*groups)
    self.image = _tile_surface(tile_type)
    self.rect = self.image.get_rect(topleft=pos)
    self.hitbox = self.rect.copy()

  def Update(self):
    pass

from settings import *

class Tile(pygame.sprite.Sprite):
  def __init__(self, pos, tile_type, *groups):
    super().__init__(*groups)
    self.image = pygame.Surface((TILE_SIZE, TILE_SIZE))
    if tile_type == "grass":
      self.image.fill(GREEN)
    elif tile_type == "road":
      self.image.fill(GRAY)
    elif tile_type == "wall":
      self.image.fill(BLACK)
    elif tile_type == "drs":
      self.image.fill(YELLOW)
    self.rect = self.image.get_rect(topleft=pos)
    self.hitbox = self.rect.copy()
  def Update(self):
    pass

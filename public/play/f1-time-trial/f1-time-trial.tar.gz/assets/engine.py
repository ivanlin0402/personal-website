from settings import *

class Engine:
  def __init__(self, name, max_speed, drs_max_speed, acceleration):
    self.name = name
    self.max_speed = max_speed
    self.drs_max_speed = drs_max_speed
    self.acceleration = acceleration

    self.idle_rpm = 1000
    self.max_rpm = 12000
    self.current_rpm = self.idle_rpm

    self.current_gear = 1
    self.max_gear = 7

    self.gear_limits = {
      0:0.00, 
      1:0.15,
      2:0.30,
      3:0.48,
      4:0.65,
      5:0.80,
      6:0.92,
      7:1.00}
  def UpdateRPM(self, current_speed):
    target_gear_limit = self.max_speed * self.gear_limits[self.current_gear]
    gear_percentage = min(1.0, current_speed / max(1.0, target_gear_limit))

    self.current_rpm = self.idle_rpm + (self.max_rpm - self.idle_rpm) * gear_percentage
    if self.gear == "auto":
      if current_speed >= target_gear_limit:
        self.ShiftUp(current_speed)
      elif current_speed < self.max_speed * self.gear_limits[self.current_gear-1]:
        self.ShiftDown(current_speed)
    return self.current_rpm
  def GetDynamicAcceleration(self):
    rpm_factor = self.current_rpm / self.max_rpm
    if rpm_factor < 0.7:
      torque_multiplier = 0.5 + (rpm_factor * 0.71)
    elif rpm_factor <= 0.88:
      torque_multiplier = 1.3
    else:
      torque_multiplier = max(0.1, 1.3 - ((rpm_factor - 0.88) * 5.0))
    gear_multiplier = 1.0 - (self.current_gear - 1) * 0.1
    base_engine_power = 0.4

    return base_engine_power * torque_multiplier * gear_multiplier

  def ShiftUp(self, current_speed):
    if self.current_gear < self.max_gear:
      self.current_gear += 1
      self.UpdateRPM(current_speed)
  def ShiftDown(self, current_speed):
    if self.current_gear > 1:
      self.current_gear -= 1
      self.UpdateRPM(current_speed)
  

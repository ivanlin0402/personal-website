from settings import *

class Wing:
  def __init__(self, angle, is_rear):
    self.angle = angle
    self.is_rear = is_rear
    self.drs_open = False
    self.health = 1.0
  def get_downforce(self):
    base_downforce = self.angle * self.health
    if self.is_rear and self.drs_open:
      return base_downforce * DRS_DOWNFORCE_MULTIPLIER
    return base_downforce
  def get_drag(self):
    base_drag = self.angle * WING_BASE_DRAG_FACTOR
    if self.is_rear and self.drs_open:
      return base_drag * DRS_DRAG_MULTIPLIER
    if self.health < 1.0:
      return base_drag * (1.0 + (1.0 - self.health) * 0.5)
    return base_drag
  def take_damage(self, amount):
    self.health -= amount
    self.health = max(0, self.health)

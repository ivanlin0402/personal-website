from settings import *

class Team:
  def __init__(self, name):

    self.name = name

    self.cars = []
    self.drivers = []
  def AddCar(self, car):
    self.cars.append(car)
    car.team = self
  def AddDriver(self, driver):
    self.drivers.append(driver)
    driver.team = self

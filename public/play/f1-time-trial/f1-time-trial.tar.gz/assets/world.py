from settings import *
from tracks import *
from tile import Tile

class World:
  def __init__(self, track_name, all_sprites, obstacle_sprites, drs_sprites):
    self.track_name = track_name
    self.track = NAME_TO_TRACK[self.track_name]
    self.all_sprites = all_sprites
    self.obstacle_sprites = obstacle_sprites
    self.drs_sprites = drs_sprites
    self.CreateTrack()
  def CreateTrack(self):
    for row_index, row in enumerate(self.track):
      for col_index, tile_id in enumerate(row):
        x = col_index * TILE_SIZE
        y = row_index * TILE_SIZE
        if tile_id == "wall":
          Tile((x, y), tile_id, self.all_sprites, self.obstacle_sprites)
        elif tile_id == "drs":
          Tile((x, y), tile_id, self.all_sprites, self.drs_sprites)
        else:
          Tile((x, y), tile_id, self.all_sprites)

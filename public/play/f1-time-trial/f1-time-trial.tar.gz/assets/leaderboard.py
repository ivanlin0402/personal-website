"""Top-50 lap time leaderboard (rank, year, team, driver, time).

On the web build, ranks sync through window.F1LB → Supabase (global).
Desktop / offline falls back to a local file or localStorage.

Shows a scrollable top 50 (blank slots if empty) plus a LAST LAP footer
with the real rank even when that rank is worse than 50.
"""

from __future__ import annotations

import json
import os
import platform

from settings import *
from assets_util import load_font

STORAGE_KEY = "f1_time_trial_leaderboard_v3"
HISTORY_KEY = "f1_time_trial_lap_history_v3"
LAST_KEY = "f1_time_trial_last_lap_v3"
STORAGE_FILE = "leaderboard.json"
HISTORY_FILE = "lap_history.json"
LAST_FILE = "last_lap.json"
MAX_ENTRIES = 50
VISIBLE_ROWS = 12
MIN_VALID_LAP = 5.0
MAX_VALID_LAP = 900.0
MAX_HISTORY = 500

IS_WEB = platform.system() == "Emscripten"


def format_year(year) -> str:
  try:
    value = int(year)
  except (TypeError, ValueError):
    return "—"
  if 1950 <= value <= 2100:
    return str(value)
  return "—"


def _parse_year(raw):
  try:
    value = int(raw)
  except (TypeError, ValueError):
    return None
  if 1950 <= value <= 2100:
    return value
  return None


def format_lap_time(seconds: float) -> str:
  if seconds is None or seconds == float("inf") or seconds < 0:
    return "--:--.---"
  mins = int(seconds // 60)
  secs = int(seconds % 60)
  millis = int(round((seconds - int(seconds)) * 1000))
  if millis >= 1000:
    millis = 999
  return "{:01d}:{:02d}.{:03d}".format(mins, secs, millis)


def _normalize(entries, limit=MAX_ENTRIES):
  cleaned = []
  for item in entries or []:
    try:
      team = str(item.get("team", "?"))[:24]
      driver = str(item.get("driver", "?"))[:24]
      time_s = float(item.get("time", 0))
      year = _parse_year(item.get("year"))
    except Exception:
      continue
    if MIN_VALID_LAP <= time_s <= MAX_VALID_LAP:
      cleaned.append({"team": team, "driver": driver, "time": time_s, "year": year})
  cleaned.sort(key=lambda e: e["time"])
  return cleaned[:limit]


def _normalize_last(last):
  if not isinstance(last, dict):
    return None
  try:
    time_s = float(last.get("time", 0))
    rank = int(last.get("rank", 0))
  except Exception:
    return None
  if not (MIN_VALID_LAP <= time_s <= MAX_VALID_LAP) or rank < 1:
    return None
  return {
    "team": str(last.get("team", "?"))[:24],
    "driver": str(last.get("driver", "?"))[:24],
    "time": time_s,
    "rank": rank,
    "year": _parse_year(last.get("year")),
  }


class Leaderboard:
  def __init__(self):
    self.visible = False
    self.entries = []
    self.history_times = []  # all known lap times for local ranking
    self.last_lap = None  # {team, driver, time, rank, year}
    self.mode = "local"  # "global" when Supabase bridge is active
    self.scroll = 0
    self._font = None
    self._title_font = None
    self._bridge = None
    self.load_local()
    self._bind_bridge()

  def _fonts(self):
    if self._font is None:
      self._font = load_font(18)
      self._title_font = load_font(26)
      try:
        self._title_font.set_bold(True)
      except Exception:
        pass
    return self._title_font, self._font

  def _bind_bridge(self) -> None:
    if not IS_WEB:
      return
    try:
      from platform import window

      self._bridge = getattr(window, "F1LB", None)
    except Exception as exc:
      print("F1LB bridge missing:", exc)
      self._bridge = None

  def toggle(self) -> None:
    self.visible = not self.visible
    if self.visible:
      self.poll()
      self.scroll = 0

  def _max_scroll(self) -> int:
    return max(0, MAX_ENTRIES - VISIBLE_ROWS)

  def handle_event(self, event) -> bool:
    """Scroll the top-50 list. Returns True if the event was consumed."""
    if not self.visible:
      return False
    if event.type == pygame.KEYDOWN:
      if event.key in (pygame.K_UP, pygame.K_w):
        self.scroll = max(0, self.scroll - 1)
        return True
      if event.key in (pygame.K_DOWN, pygame.K_s):
        self.scroll = min(self._max_scroll(), self.scroll + 1)
        return True
      if event.key == pygame.K_PAGEUP:
        self.scroll = max(0, self.scroll - VISIBLE_ROWS)
        return True
      if event.key == pygame.K_PAGEDOWN:
        self.scroll = min(self._max_scroll(), self.scroll + VISIBLE_ROWS)
        return True
    if event.type == pygame.MOUSEWHEEL:
      self.scroll = max(0, min(self._max_scroll(), self.scroll - int(event.y)))
      return True
    return False

  def _read_storage(self, key, path):
    try:
      if IS_WEB:
        from platform import window

        return window.localStorage.getItem(key)
      if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
          return f.read()
    except Exception as exc:
      print("leaderboard read failed:", key, exc)
    return None

  def _write_storage(self, key, path, payload: str) -> None:
    try:
      if IS_WEB:
        from platform import window

        window.localStorage.setItem(key, payload)
      else:
        with open(path, "w", encoding="utf-8") as f:
          f.write(payload)
    except Exception as exc:
      print("leaderboard write failed:", key, exc)

  def load_local(self) -> None:
    raw = self._read_storage(STORAGE_KEY, STORAGE_FILE)
    data = []
    if raw:
      try:
        parsed = json.loads(raw)
        if isinstance(parsed, list):
          data = parsed
      except Exception as exc:
        print("leaderboard parse failed:", exc)
    self.entries = _normalize(data)

    hist_raw = self._read_storage(HISTORY_KEY, HISTORY_FILE)
    times = []
    if hist_raw:
      try:
        parsed = json.loads(hist_raw)
        if isinstance(parsed, list):
          for t in parsed:
            try:
              val = float(t)
            except Exception:
              continue
            if MIN_VALID_LAP <= val <= MAX_VALID_LAP:
              times.append(val)
      except Exception as exc:
        print("history parse failed:", exc)
    if not times:
      times = [e["time"] for e in self.entries]
    self.history_times = times[-MAX_HISTORY:]

    last_raw = self._read_storage(LAST_KEY, LAST_FILE)
    if last_raw:
      try:
        self.last_lap = _normalize_last(json.loads(last_raw))
      except Exception:
        self.last_lap = None

  def save_local(self) -> None:
    self._write_storage(STORAGE_KEY, STORAGE_FILE, json.dumps(self.entries[:MAX_ENTRIES]))
    self._write_storage(
      HISTORY_KEY,
      HISTORY_FILE,
      json.dumps(self.history_times[-MAX_HISTORY:]),
    )
    if self.last_lap is not None:
      self._write_storage(LAST_KEY, LAST_FILE, json.dumps(self.last_lap))

  def _same_lap(self, left, right) -> bool:
    try:
      return (
        left.get("team") == right.get("team")
        and left.get("driver") == right.get("driver")
        and left.get("year") == right.get("year")
        and round(float(left.get("time", 0)), 3) == round(float(right.get("time", 0)), 3)
      )
    except Exception:
      return False

  def _index_on_board(self, entry):
    """1-based row on the top-50 list, or None if this lap is not shown."""
    found = None
    for i, item in enumerate(self.entries):
      if self._same_lap(item, entry):
        found = i + 1
    return found

  def _rank_for(self, entry) -> int:
    """Same number as the # column when the lap is on the top 50."""
    on_board = self._index_on_board(entry)
    if on_board is not None:
      return on_board
    lap_time = float(entry["time"])
    faster = sum(1 for t in self.history_times if t < lap_time)
    equals = sum(1 for t in self.history_times if t == lap_time)
    return max(1, faster + equals)

  def _align_last_rank(self) -> None:
    if not self.last_lap:
      return
    on_board = self._index_on_board(self.last_lap)
    if on_board is not None:
      self.last_lap["rank"] = on_board

  def poll(self) -> None:
    """Pull latest global board from the JS bridge when available."""
    if not IS_WEB:
      return
    if self._bridge is None:
      self._bind_bridge()
    if self._bridge is None:
      return
    try:
      raw = self._bridge.getState()
      data = json.loads(str(raw))
      mode = data.get("mode") or "local"
      self.mode = mode
      remote = _normalize(data.get("entries") or [])
      # Global: bridge/server is source of truth.
      # Local: never merge every frame — that duplicated one lap into every row.
      if mode == "global":
        self.entries = remote
      last = _normalize_last(data.get("last"))
      if last is not None:
        self.last_lap = last
    except Exception as exc:
      print("leaderboard poll failed:", exc)

  def submit(self, team: str, driver: str, lap_time: float, year=None) -> bool:
    """Record a completed last lap into the global board (or local fallback)."""
    if lap_time is None or lap_time == float("inf"):
      return False
    if not (MIN_VALID_LAP <= float(lap_time) <= MAX_VALID_LAP):
      return False

    entry = {
      "team": str(team)[:24],
      "driver": str(driver)[:24],
      "time": float(lap_time),
      "year": _parse_year(year),
    }

    self.history_times.append(entry["time"])
    self.history_times = self.history_times[-MAX_HISTORY:]

    # Add this completed lap once, then rank it as the matching top-50 row
    self.entries = _normalize(self.entries + [entry])
    self.last_lap = {
      "team": entry["team"],
      "driver": entry["driver"],
      "time": entry["time"],
      "rank": self._rank_for(entry),
      "year": entry["year"],
    }

    if IS_WEB:
      if self._bridge is None:
        self._bind_bridge()
      if self._bridge is not None:
        try:
          self._bridge.submit(
            entry["team"],
            entry["driver"],
            entry["time"],
            entry["year"] if entry["year"] is not None else 0,
          )
          self.poll()
          self.save_local()
          return True
        except Exception as exc:
          print("leaderboard global submit failed:", exc)

    self.save_local()
    return True

  def draw(self, screen) -> None:
    if not self.visible:
      return

    self.poll()
    self._align_last_rank()
    title_font, font = self._fonts()
    panel = pygame.Rect(60, 36, WINDOW_WIDTH - 120, WINDOW_HEIGHT - 72)
    overlay = pygame.Surface((WINDOW_WIDTH, WINDOW_HEIGHT), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 160))
    screen.blit(overlay, (0, 0))

    pygame.draw.rect(screen, (20, 20, 24), panel)
    pygame.draw.rect(screen, (220, 220, 220), panel, 2)

    title = title_font.render("TOP 50 LAP TIMES", True, WHITE)
    screen.blit(title, (panel.x + 20, panel.y + 12))
    mode_label = "GLOBAL" if self.mode == "global" else "LOCAL (this device)"
    hint = font.render(
      "Tab close  ·  arrows/wheel scroll  ·  " + mode_label,
      True,
      (160, 160, 160),
    )
    screen.blit(hint, (panel.x + 20, panel.y + 42))

    headers = [(" #", 16), ("YEAR", 50), ("TEAM", 110), ("DRIVER", 280), ("LAP TIME", 470)]
    y = panel.y + 70
    for label, x_off in headers:
      screen.blit(font.render(label, True, (180, 180, 180)), (panel.x + x_off, y))
    pygame.draw.line(
      screen,
      (80, 80, 80),
      (panel.x + 16, y + 20),
      (panel.right - 16, y + 20),
      1,
    )

    y += 26
    start = self.scroll
    end = min(MAX_ENTRIES, start + VISIBLE_ROWS)
    for i in range(start + 1, end + 1):
      rank_color = (
        (255, 215, 0) if i == 1 else (220, 220, 220) if i <= 3 else (200, 200, 200)
      )
      if i <= len(self.entries):
        entry = self.entries[i - 1]
        row = [
          ("{:2d}".format(i), 16, rank_color),
          (format_year(entry.get("year")), 50, WHITE),
          (entry["team"], 110, WHITE),
          (entry["driver"], 280, WHITE),
          (format_lap_time(entry["time"]), 470, rank_color),
        ]
      else:
        blank = (120, 120, 120)
        row = [
          ("{:2d}".format(i), 16, blank),
          ("—", 50, blank),
          ("—", 110, blank),
          ("—", 280, blank),
          ("--:--.---", 470, blank),
        ]
      for text, x_off, color in row:
        screen.blit(font.render(text, True, color), (panel.x + x_off, y))
      y += 24

    range_label = font.render(
      "{:02d}-{:02d} / 50".format(start + 1, end),
      True,
      (140, 140, 140),
    )
    screen.blit(range_label, (panel.right - 110, panel.y + 16))

    # LAST LAP footer (rank can be > 50)
    y += 6
    pygame.draw.line(
      screen,
      (80, 80, 80),
      (panel.x + 16, y),
      (panel.right - 16, y),
      1,
    )
    y += 10
    screen.blit(font.render("LAST LAP", True, (180, 180, 180)), (panel.x + 20, y))
    y += 26

    if self.last_lap is None:
      blank = (120, 120, 120)
      row = [
        (" —", 16, blank),
        ("—", 50, blank),
        ("—", 110, blank),
        ("—", 280, blank),
        ("--:--.---", 470, blank),
      ]
    else:
      last = self.last_lap
      accent = (120, 200, 255)
      row = [
        (f"{last['rank']:2d}", 16, accent),
        (format_year(last.get("year")), 50, WHITE),
        (last["team"], 110, WHITE),
        (last["driver"], 280, WHITE),
        (format_lap_time(last["time"]), 470, accent),
      ]
    for text, x_off, color in row:
      screen.blit(font.render(text, True, color), (panel.x + x_off, y))

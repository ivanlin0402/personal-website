"""Top-10 lap time leaderboard (rank, team, driver, time)."""

from __future__ import annotations

import json
import os
import platform

from settings import *
from assets_util import load_font

STORAGE_KEY = "f1_time_trial_leaderboard"
STORAGE_FILE = "leaderboard.json"
MAX_ENTRIES = 10
MIN_VALID_LAP = 5.0  # ignore accidental tiny times

IS_WEB = platform.system() == "Emscripten"


def format_lap_time(seconds: float) -> str:
  if seconds is None or seconds == float("inf") or seconds < 0:
    return "--:--.---"
  mins = int(seconds // 60)
  secs = int(seconds % 60)
  millis = int(round((seconds - int(seconds)) * 1000))
  if millis >= 1000:
    millis = 999
  return "{:01d}:{:02d}.{:03d}".format(mins, secs, millis)


class Leaderboard:
  def __init__(self):
    self.visible = False
    self.entries = []  # list of {team, driver, time}
    self._font = None
    self._title_font = None
    self.load()

  def _fonts(self):
    if self._font is None:
      self._font = load_font(18)
      self._title_font = load_font(26)
      try:
        self._title_font.set_bold(True)
      except Exception:
        pass
    return self._title_font, self._font

  def toggle(self) -> None:
    self.visible = not self.visible

  def load(self) -> None:
    raw = None
    try:
      if IS_WEB:
        from platform import window

        raw = window.localStorage.getItem(STORAGE_KEY)
      elif os.path.exists(STORAGE_FILE):
        with open(STORAGE_FILE, "r", encoding="utf-8") as f:
          raw = f.read()
    except Exception as exc:
      print("leaderboard load failed:", exc)
      raw = None

    entries = []
    if raw:
      try:
        data = json.loads(raw)
        if isinstance(data, list):
          for item in data:
            team = str(item.get("team", "?"))[:24]
            driver = str(item.get("driver", "?"))[:24]
            time_s = float(item.get("time", 0))
            if time_s >= MIN_VALID_LAP:
              entries.append({"team": team, "driver": driver, "time": time_s})
      except Exception as exc:
        print("leaderboard parse failed:", exc)

    entries.sort(key=lambda e: e["time"])
    self.entries = entries[:MAX_ENTRIES]

  def save(self) -> None:
    payload = json.dumps(self.entries[:MAX_ENTRIES])
    try:
      if IS_WEB:
        from platform import window

        window.localStorage.setItem(STORAGE_KEY, payload)
      else:
        with open(STORAGE_FILE, "w", encoding="utf-8") as f:
          f.write(payload)
    except Exception as exc:
      print("leaderboard save failed:", exc)

  def submit(self, team: str, driver: str, lap_time: float) -> bool:
    """Record a completed last lap. Keeps only the top 10 fastest times."""
    if lap_time is None or lap_time == float("inf"):
      return False
    if not (lap_time >= MIN_VALID_LAP):
      return False

    self.entries.append(
      {
        "team": str(team)[:24],
        "driver": str(driver)[:24],
        "time": float(lap_time),
      }
    )
    self.entries.sort(key=lambda e: e["time"])
    self.entries = self.entries[:MAX_ENTRIES]
    self.save()
    return True

  def draw(self, screen) -> None:
    if not self.visible:
      return

    title_font, font = self._fonts()
    panel = pygame.Rect(80, 70, WINDOW_WIDTH - 160, WINDOW_HEIGHT - 140)
    overlay = pygame.Surface((WINDOW_WIDTH, WINDOW_HEIGHT), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 160))
    screen.blit(overlay, (0, 0))

    pygame.draw.rect(screen, (20, 20, 24), panel)
    pygame.draw.rect(screen, (220, 220, 220), panel, 2)

    title = title_font.render("TOP 10 LAP TIMES", True, WHITE)
    screen.blit(title, (panel.x + 20, panel.y + 16))
    hint = font.render("Tab to close  ·  last lap only", True, (160, 160, 160))
    screen.blit(hint, (panel.x + 20, panel.y + 48))

    headers = [(" #", 20), ("TEAM", 70), ("DRIVER", 280), ("LAP TIME", 480)]
    y = panel.y + 84
    for label, x_off in headers:
      screen.blit(font.render(label, True, (180, 180, 180)), (panel.x + x_off, y))
    pygame.draw.line(
      screen,
      (80, 80, 80),
      (panel.x + 16, y + 24),
      (panel.right - 16, y + 24),
      1,
    )

    y += 36
    if not self.entries:
      empty = font.render("No laps yet — cross the finish line to set a time.", True, (150, 150, 150))
      screen.blit(empty, (panel.x + 20, y + 20))
      return

    for i, entry in enumerate(self.entries[:MAX_ENTRIES], start=1):
      rank_color = (255, 215, 0) if i == 1 else (220, 220, 220) if i <= 3 else (200, 200, 200)
      row = [
        (f"{i:2d}", 20, rank_color),
        (entry["team"], 70, WHITE),
        (entry["driver"], 280, WHITE),
        (format_lap_time(entry["time"]), 480, rank_color),
      ]
      for text, x_off, color in row:
        screen.blit(font.render(text, True, color), (panel.x + x_off, y))
      y += 32

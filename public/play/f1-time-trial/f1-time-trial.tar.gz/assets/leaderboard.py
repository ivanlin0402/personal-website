"""Top-10 lap time leaderboard (rank, team, driver, time).

On the web build, ranks sync through window.F1LB → Supabase (global).
Desktop / offline falls back to a local file or localStorage.
"""

from __future__ import annotations

import json
import os
import platform

from settings import *
from assets_util import load_font

STORAGE_KEY = "f1_time_trial_leaderboard"
STORAGE_FILE = "leaderboard.json"
MAX_ENTRIES = 10
MIN_VALID_LAP = 5.0
MAX_VALID_LAP = 900.0

IS_WEB = platform.system() == "Emscripten"


def format_lap_time(seconds: float) -> str:
  if seconds is None or seconds == float("inf") or seconds < 0:
    return "--:--.---"
  mins = int(seconds // 60)
  secs = int(seconds % 60)
  millis = int(round((seconds - int(seconds)) * 1000))
  if millis >= 1000:
    millis = 999
  return "{:01d}:{:02d}.{:03d}".format(mins, secs, millis)


def _normalize(entries):
  cleaned = []
  for item in entries or []:
    try:
      team = str(item.get("team", "?"))[:24]
      driver = str(item.get("driver", "?"))[:24]
      time_s = float(item.get("time", 0))
    except Exception:
      continue
    if MIN_VALID_LAP <= time_s <= MAX_VALID_LAP:
      cleaned.append({"team": team, "driver": driver, "time": time_s})
  cleaned.sort(key=lambda e: e["time"])
  return cleaned[:MAX_ENTRIES]


class Leaderboard:
  def __init__(self):
    self.visible = False
    self.entries = []
    self.mode = "local"  # "global" when Supabase bridge is active
    self._font = None
    self._title_font = None
    self._bridge = None
    self.load_local()
    self._bind_bridge()

  def _fonts(self):
    if self._font is None:
      self._font = load_font(18)
      self._title_font = load_font(26)
      try:
        self._title_font.set_bold(True)
      except Exception:
        pass
    return self._title_font, self._font

  def _bind_bridge(self) -> None:
    if not IS_WEB:
      return
    try:
      from platform import window

      self._bridge = getattr(window, "F1LB", None)
    except Exception as exc:
      print("F1LB bridge missing:", exc)
      self._bridge = None

  def toggle(self) -> None:
    self.visible = not self.visible
    if self.visible:
      self.poll()

  def load_local(self) -> None:
    raw = None
    try:
      if IS_WEB:
        from platform import window

        raw = window.localStorage.getItem(STORAGE_KEY)
      elif os.path.exists(STORAGE_FILE):
        with open(STORAGE_FILE, "r", encoding="utf-8") as f:
          raw = f.read()
    except Exception as exc:
      print("leaderboard local load failed:", exc)
      raw = None

    data = []
    if raw:
      try:
        parsed = json.loads(raw)
        if isinstance(parsed, list):
          data = parsed
      except Exception as exc:
        print("leaderboard parse failed:", exc)
    self.entries = _normalize(data)

  def save_local(self) -> None:
    payload = json.dumps(self.entries[:MAX_ENTRIES])
    try:
      if IS_WEB:
        from platform import window

        window.localStorage.setItem(STORAGE_KEY, payload)
      else:
        with open(STORAGE_FILE, "w", encoding="utf-8") as f:
          f.write(payload)
    except Exception as exc:
      print("leaderboard local save failed:", exc)

  def poll(self) -> None:
    """Pull latest global board from the JS bridge when available."""
    if not IS_WEB:
      return
    if self._bridge is None:
      self._bind_bridge()
    if self._bridge is None:
      return
    try:
      raw = self._bridge.getState()
      data = json.loads(str(raw))
      mode = data.get("mode") or "local"
      self.mode = mode
      remote = _normalize(data.get("entries") or [])
      if mode == "global":
        self.entries = remote
      elif remote:
        # Prefer whichever list has better/more times while waiting for global
        merged = _normalize(self.entries + remote)
        self.entries = merged
    except Exception as exc:
      print("leaderboard poll failed:", exc)

  def submit(self, team: str, driver: str, lap_time: float) -> bool:
    """Record a completed last lap into the global board (or local fallback)."""
    if lap_time is None or lap_time == float("inf"):
      return False
    if not (MIN_VALID_LAP <= float(lap_time) <= MAX_VALID_LAP):
      return False

    entry = {
      "team": str(team)[:24],
      "driver": str(driver)[:24],
      "time": float(lap_time),
    }

    if IS_WEB:
      if self._bridge is None:
        self._bind_bridge()
      if self._bridge is not None:
        try:
          self._bridge.submit(entry["team"], entry["driver"], entry["time"])
          self.poll()
          # Still keep a local cache for instant UI
          self.entries = _normalize(self.entries + [entry])
          self.save_local()
          return True
        except Exception as exc:
          print("leaderboard global submit failed:", exc)

    self.entries = _normalize(self.entries + [entry])
    self.save_local()
    return True

  def draw(self, screen) -> None:
    if not self.visible:
      return

    self.poll()
    title_font, font = self._fonts()
    panel = pygame.Rect(80, 70, WINDOW_WIDTH - 160, WINDOW_HEIGHT - 140)
    overlay = pygame.Surface((WINDOW_WIDTH, WINDOW_HEIGHT), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 160))
    screen.blit(overlay, (0, 0))

    pygame.draw.rect(screen, (20, 20, 24), panel)
    pygame.draw.rect(screen, (220, 220, 220), panel, 2)

    title = title_font.render("TOP 10 LAP TIMES", True, WHITE)
    screen.blit(title, (panel.x + 20, panel.y + 16))
    mode_label = "GLOBAL" if self.mode == "global" else "LOCAL (this device)"
    hint = font.render(
      "Tab to close  ·  last lap only  ·  " + mode_label,
      True,
      (160, 160, 160),
    )
    screen.blit(hint, (panel.x + 20, panel.y + 48))

    headers = [(" #", 20), ("TEAM", 70), ("DRIVER", 280), ("LAP TIME", 480)]
    y = panel.y + 84
    for label, x_off in headers:
      screen.blit(font.render(label, True, (180, 180, 180)), (panel.x + x_off, y))
    pygame.draw.line(
      screen,
      (80, 80, 80),
      (panel.x + 16, y + 24),
      (panel.right - 16, y + 24),
      1,
    )

    y += 36
    if not self.entries:
      empty = font.render(
        "No laps yet — finish a lap to set a time.",
        True,
        (150, 150, 150),
      )
      screen.blit(empty, (panel.x + 20, y + 20))
      if self.mode != "global":
        setup = font.render(
          "Global ranks need Supabase config on the website build.",
          True,
          (150, 150, 150),
        )
        screen.blit(setup, (panel.x + 20, y + 52))
      return

    for i, entry in enumerate(self.entries[:MAX_ENTRIES], start=1):
      rank_color = (
        (255, 215, 0) if i == 1 else (220, 220, 220) if i <= 3 else (200, 200, 200)
      )
      row = [
        (f"{i:2d}", 20, rank_color),
        (entry["team"], 70, WHITE),
        (entry["driver"], 280, WHITE),
        (format_lap_time(entry["time"]), 480, rank_color),
      ]
      for text, x_off, color in row:
        screen.blit(font.render(text, True, color), (panel.x + x_off, y))
      y += 32

import asyncio

from game import Game


async def main():
    game = Game()
    await game.Run()


asyncio.run(main())

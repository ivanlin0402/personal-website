import asyncio
import platform
import traceback

import pygame

from settings import WINDOW_WIDTH, WINDOW_HEIGHT
from game import Game


async def main():
  print("F1 Time Trial starting...")
  try:
    pygame.init()
    screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
    try:
      pygame.key.stop_text_input()
    except Exception:
      pass
    pygame.display.set_caption("F1 Time Trial")

    # First paint immediately so the page is not stuck on gray
    screen.fill((0, 0, 0))
    from assets_util import load_font

    font = load_font(48)
    label = font.render("Loading menu...", True, (255, 255, 255))
    screen.blit(label, (WINDOW_WIDTH // 2 - label.get_width() // 2, WINDOW_HEIGHT // 2))
    pygame.display.flip()
    await asyncio.sleep(0)

    game = Game(screen)
    await game.Run()
  except Exception:
    traceback.print_exc()
    # Keep showing an error on canvas if possible
    try:
      screen = pygame.display.get_surface()
      if screen is not None:
        screen.fill((40, 0, 0))
        from assets_util import load_font
        font = load_font(22)
        y = 40
        for line in traceback.format_exc().splitlines()[-12:]:
          surf = font.render(line[:90], True, (255, 220, 220))
          screen.blit(surf, (20, y))
          y += 24
        pygame.display.flip()
        for _ in range(600):
          await asyncio.sleep(0.05)
    except Exception:
      pass
  finally:
    if platform.system() != "Emscripten":
      pygame.quit()


asyncio.run(main())

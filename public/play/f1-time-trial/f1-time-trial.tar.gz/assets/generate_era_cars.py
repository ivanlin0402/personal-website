"""Build 22x38 period-correct car sprites (shape + livery) from era maps."""
from pathlib import Path

from PIL import Image

from liveries import livery_for
from seasons import SEASONS, car_sprite_id

ASSETS = Path(__file__).resolve().parent / "assets"
TEMPLATE = ASSETS / "SF26.png"
BG = (186, 254, 202, 255)
BLACK = (0, 0, 0, 255)
YELLOW = (240, 250, 6, 255)
WHITE = (255, 255, 255, 255)
W, H = 22, 38

# . bg  K black  Y yellow  W white  P primary  D shadow  H highlight  A accent
# 1988-94: short nose, high airbox, no halo (MP4/4)
CLASSIC = """\
......................
......................
......KPPPPPPPPK......
......KPPPPPPPPK......
.......KAAAAAAK.......
........KAAAAK........
..KKK....HHHH....KKK..
..KWKK..KPPPPK..KKWK..
..K.KKK.KPPPPK.KKK.K..
..KKKK..KPPPPK..KKKK..
..KKK....PPPP....KKK..
.........PPPP.........
........KPPPPK........
.......KKKKKKKK.......
.......KHHHHHHK.......
......KHPPPPPPHK......
.....AAPPPPPPPPAA.....
.....AAPPPPPPPPAA.....
.....AHPPPPPPPPHA.....
.....AHPPPPPPPPHA.....
.....AAPPPPPPPPAA.....
.....AAPPPPPPPPAA.....
.....KKPPPPPPPPKK.....
...KKKKPPPPPPPPKKKK...
..KWWKKKPPPPPPKKKWWK..
..K..KKKPPPPPPKKK..K..
..KKKKKKPPPPPPKKKKKK..
..KKKKKKKKKKKKKKKKKK..
...KKK.PKPKPKPK.KKK...
.......PPPPPPPP.......
.......PPPPPPPP.......
.......PWWWWWWP.......
......KPPPPPPPPK......
......KKKKKKKKKK......
......................
......................
......................
......................
"""

# 1995-2008: longer high nose, detached wing, no halo
HIGHNOSE = """\
......................
......................
....KKPPPPPPPPPPKK....
....KPPPPPPPPPPPPK....
.....K....PP....K.....
.........HPPH.........
..KKK....HPPH....KKK..
..KWKK...HPPH...KKWK..
..K.KKK..KPPK..KKK.K..
..KKKK...KPPK...KKKK..
..KKK....KPPK....KKK..
.........KPPK.........
.........KPPK.........
........KKKKKK........
.......KHHHHHHK.......
......KHPPPPPPHK......
.....AAPPPPPPPPAA.....
.....AAPPPPPPPPAA.....
.....AHPPPPPPPPHA.....
.....AAPPPPPPPPAA.....
.....AAPPPPPPPPAA.....
.....KKPPPPPPPPKK.....
.....KKPPPPPPPPKK.....
...KKKKPPPPPPPPKKKK...
..KWWKKKPPPPPPKKKWWK..
..K..KKKPPPPPPKKK..K..
..KKKKKKPPPPPPKKKKKK..
..KKKKKKKKKKKKKKKKKK..
...KKK.PKPKPKPK.KKK...
.......PPPPPPPP.......
.......RRRRRRRR.......
.......PWWWWWWP.......
......KPPPPPPPPK......
......KKKKKKKKKK......
......................
......................
......................
......................
""".replace("R", "P")

# 2009-2017: wide front wing, no halo
WIDE = """\
......................
......................
..KKPPPPPPPPPPPPPPKK..
..KPPPPPPPPPPPPPPPPK..
..K......HHHH......K..
.........HPPPH........
..KKK....HPPPH...KKK..
..KWKK...KPPPK..KKWK..
..K.KKK..KPPPK.KKK.K..
..KKKK...KPPPK..KKKK..
..KKK....KPPPK...KKK..
.........KPPPK........
........KKKKKKK.......
.......KHHHHHHK.......
......KHPPPPPPHK......
.....AAPPPPPPPPAA.....
.....AHPPPPPPPPHA.....
.....AAPPPPPPPPAA.....
.....AAPPPPPPPPAA.....
.....KKPPPPPPPPKK.....
.....KKPPPPPPPPKK.....
.....KKPPPPPPPPKK.....
...KKKKPPPPPPPPKKKK...
..KWWKKKPPPPPPKKKWWK..
..K..KKKPPPPPPKKK..K..
..KKKKKKPPPPPPKKKKKK..
..KKKKKKKKKKKKKKKKKK..
...KKK.PKPKPKPK.KKK...
.......PPPPPPPP.......
.......PPPPPPPP.......
.......PWWWWWWP.......
......KPPPPPPPPK......
......KPPPPPPPPK......
......KKKKKKKKKK......
......................
......................
......................
......................
"""


def parse_map(text):
  rows = [line.rstrip("\n") for line in text.splitlines() if line != ""]
  if len(rows) != H:
    raise SystemExit("map height %s want %s" % (len(rows), H))
  for i, row in enumerate(rows):
    if len(row) != W:
      raise SystemExit("row %s width %s want %s: %r" % (i, len(row), W, row))
  return rows


CLASSIC_MAP = parse_map(CLASSIC)
HIGHNOSE_MAP = parse_map(HIGHNOSE)
WIDE_MAP = parse_map(WIDE)


def era_map(year):
  if year <= 1994:
    return CLASSIC_MAP
  if year <= 2008:
    return HIGHNOSE_MAP
  if year <= 2017:
    return WIDE_MAP
  return None  # 2018+ uses the accepted modern Ferrari template


def lerp(a, b, t):
  return int(a + (b - a) * t)


def mix(c1, c2, t):
  return (lerp(c1[0], c2[0], t), lerp(c1[1], c2[1], t), lerp(c1[2], c2[2], t), 255)


def is_bg(c):
  r, g, b, a = c
  return a < 16 or (g > 200 and r > 150 and b > 160 and g > r)


def is_black(c):
  r, g, b, a = c
  return a >= 16 and r < 28 and g < 28 and b < 28


def is_white(c):
  r, g, b, a = c
  return a >= 16 and r > 210 and g > 210 and b > 210


def is_yellow(c):
  r, g, b, a = c
  return a >= 16 and r > 160 and g > 160 and b < 90


def is_body(c):
  r, g, b, a = c
  return a >= 16 and r > g + 30 and r > b + 20 and r > 70


def paint_map(rows, shadow, primary, highlight, accent):
  dest = []
  for y, row in enumerate(rows):
    for ch in row:
      if ch == ".":
        dest.append(BG)
      elif ch == "K":
        dest.append(BLACK)
      elif ch == "Y":
        dest.append(YELLOW)
      elif ch == "W":
        dest.append(WHITE)
      elif ch == "D":
        dest.append((*shadow, 255))
      elif ch == "H":
        dest.append((*highlight, 255))
      elif ch == "A":
        dest.append((*(accent or primary), 255))
      else:
        dest.append((*primary, 255))
  im = Image.new("RGBA", (W, H))
  im.putdata(dest)
  return finish(im)


def paint_modern(template_pixels, shadow, primary, highlight, accent):
  reds = [c[0] for c in template_pixels if is_body(c)]
  rmin, rmax = min(reds), max(reds)
  dest = []
  for i, c in enumerate(template_pixels):
    y = i // W
    if is_bg(c):
      dest.append(BG)
    elif is_black(c):
      dest.append(BLACK)
    elif is_yellow(c):
      dest.append(YELLOW)
    elif is_white(c):
      dest.append(WHITE)
    elif is_body(c):
      t = 0 if rmax == rmin else (c[0] - rmin) / (rmax - rmin)
      if accent and t > 0.62 and 15 <= y <= 27:
        dest.append((*accent, 255))
      elif t < 0.35:
        dest.append((*shadow, 255))
      elif t > 0.8:
        dest.append((*highlight, 255))
      else:
        dest.append(mix(shadow, primary, (t - 0.35) / 0.45))
    else:
      lum = (c[0] + c[1] + c[2]) / 3
      dest.append(BLACK if lum < 120 else BG)
  im = Image.new("RGBA", (W, H))
  im.putdata(dest)
  return finish(im)


def finish(im):
  p = im.load()
  for y in range(H):
    cols = [x for x in range(W) if p[x, y] != BG]
    if cols:
      p[cols[0], y] = BLACK
      p[cols[-1], y] = BLACK
      break
  for y in range(2):
    for x in range(W):
      p[x, y] = BG
  return im


def main():
  tmpl = Image.open(TEMPLATE).convert("RGBA")
  pixels = list(tmpl.getdata())
  written = 0
  for year, teams in SEASONS.items():
    rows = era_map(year)
    for spec in teams:
      name = spec["name"]
      stem = car_sprite_id(year, name)
      shadow, primary, highlight, accent = livery_for(year, name, spec["color"])
      if rows is None:
        im = paint_modern(pixels, shadow, primary, highlight, accent)
      else:
        im = paint_map(rows, shadow, primary, highlight, accent)
      assert im.size == (W, H), (stem, im.size)
      im.save(ASSETS / ("%s.png" % stem))
      written += 1
  print("wrote", written, "sprites")


if __name__ == "__main__":
  main()

"""Build 22x38 period-correct cars from the accepted Ferrari pixel template."""
from pathlib import Path

from PIL import Image

from liveries import livery_for
from seasons import SEASONS, car_sprite_id

ASSETS = Path(__file__).resolve().parent / "assets"
TEMPLATE = ASSETS / "SF26.png"
BG = (186, 254, 202, 255)
BLACK = (0, 0, 0, 255)
YELLOW = (240, 250, 6, 255)
WHITE = (255, 255, 255, 255)
W, H = 22, 38

# Accepted Ferrari SF26, body as B. Wheels / lights / wings stay on every era.
SF26 = """\
......................
......................
.......KKBBBKK........
......KBBBBBBBK.......
.....KBBKKBKKBBK......
.....KBK..Y..KBK......
..KKK.....B.....KKK...
..KWKK.KKKBKKK.KKWK...
..K.KKK..KBK..KKK.K...
..KKKK.K.KBK.K.KKKK...
..KKK..K.KBK.K..KKK...
........KKBKK.........
.........KBK..........
.........KBK..........
.......KBKKKKK........
......KKBKKKKKK.......
......KBBKBKKBK.......
......BBBBKBBBB.......
.....BYBBKBKBBYB......
.....BYBBBBBBBYB......
.....BBBBBBBBBBB......
.....KBBBBBBBBBK......
.....KBBBBBBBBBK......
.....KKBBBBBBBBK......
.....KKBBBBBBBKK......
.....KKBBKBKBBKK......
...KKKKBBKKKBBKKKK....
..KWWKKKBBKBBKKKWWK...
..K..KKKBBKBBKKK..K...
..KKKKKKBKKKBKKKKKK...
..KKKKKKKKKKKKKKKKKK..
...KKK.BKBKBKB.KKK....
.......BKBKBKB........
.......BBBBBBB........
.......BW.WWWB........
.......KKKKKKK........
......................
......................
"""

# 1988-94: same wheels/wings language, short nose, no halo (MP4/4)
CLASSIC_PATCH = {
  2: "......KKBBBBBBKK......",
  3: "......KBBBBBBBK.......",
  4: ".......KAAAAAAK.......",
  5: ".......KA.Y.AK........",
  11: ".......KBBBBBK........",
  12: "......KBBBBBBBK.......",
  13: "......KBBKKKBBK.......",
  14: "......KBBKKKBBK.......",
  15: ".....KHHBKKKBHHK......",
  16: ".....KBBBBBBBBBK......",
  17: ".....ABBBBBBBBBA......",
  18: ".....AYBBBBBBYA.......",
  19: ".....ABBBBBBBBBA......",
  20: ".....ABBBBBBBBBA......",
  21: ".....KABBBBBBBAK......",
  22: ".....KABBBBBBBAK......",
}

# 1995-2008: high nose, no halo
HIGHNOSE_PATCH = {
  4: ".....K....B....K......",
  5: ".....K...Y.Y...K......",
  11: ".........KBK..........",
  12: ".........KBK..........",
  13: "........KBBBK.........",
  14: ".......KBBKKBBK.......",
  15: "......KBBKKKBBK.......",
  16: "......KBBBBBBBK.......",
  17: ".....ABBBBBBBBBA......",
  18: ".....AYBBBBBBYA.......",
  19: ".....ABBBBBBBBBA......",
  20: ".....ABBBBBBBBBA......",
}

# 2009-17: modern wide wing, still no halo
WIDE_PATCH = {
  11: "........KBBBK.........",
  12: ".......KBBBBBK........",
  13: "......KBBKKKBBK.......",
  14: "......KBBKKKBBK.......",
  15: "......KBBKKKBBK.......",
  16: "......KBBBBBBBK.......",
  17: ".....ABBBBBBBBBA......",
  18: ".....AYBBKBKBYA.......",
  19: ".....ABBBBBBBBBA......",
  20: ".....ABBBBBBBBBA......",
}


def parse(text):
  rows = [line for line in text.splitlines() if line != ""]
  if len(rows) != H:
    raise SystemExit("height %s" % len(rows))
  grid = []
  for i, row in enumerate(rows):
    if len(row) != W:
      raise SystemExit("row %s width %s %r" % (i, len(row), row))
    grid.append(list(row))
  return grid


def patched(base, patch):
  g = [row[:] for row in base]
  for y, s in patch.items():
    if len(s) != W:
      raise SystemExit("patch %s width %s %r" % (y, len(s), s))
    g[y] = list(s)
  return g


BASE = parse(SF26)
# SF26 dump row 30 is 21 chars in one source comment; parser validates.
CLASSIC = patched(BASE, CLASSIC_PATCH)
HIGHNOSE = patched(BASE, HIGHNOSE_PATCH)
WIDE = patched(BASE, WIDE_PATCH)


def era_grid(year):
  if year <= 1994:
    return CLASSIC
  if year <= 2008:
    return HIGHNOSE
  if year <= 2017:
    return WIDE
  return BASE


def lerp(a, b, t):
  return int(a + (b - a) * t)


def mix(c1, c2, t):
  return (lerp(c1[0], c2[0], t), lerp(c1[1], c2[1], t), lerp(c1[2], c2[2], t), 255)


def is_bg(c):
  r, g, b, a = c
  return a < 16 or (g > 200 and r > 150 and b > 160 and g > r)


def is_black(c):
  r, g, b, a = c
  return a >= 16 and r < 28 and g < 28 and b < 28


def is_white(c):
  r, g, b, a = c
  return a >= 16 and r > 210 and g > 210 and b > 210


def is_yellow(c):
  r, g, b, a = c
  return a >= 16 and r > 160 and g > 160 and b < 90


def is_body(c):
  r, g, b, a = c
  return a >= 16 and r > g + 30 and r > b + 20 and r > 70


def color_for(ch, x, y, shadow, primary, highlight, accent):
  if ch == ".":
    return BG
  if ch == "K":
    return BLACK
  if ch == "Y":
    return YELLOW
  if ch == "W":
    return WHITE
  if ch == "D":
    return (*shadow, 255)
  if ch == "H":
    return (*highlight, 255)
  if ch == "A":
    return (*(accent or primary), 255)
  # B and anything else: body, edge-shaded
  if x <= 6 or x >= 15 or y in (21, 24, 25):
    return (*shadow, 255)
  if 9 <= x <= 12:
    return (*highlight, 255)
  return (*primary, 255)


def paint_grid(grid, shadow, primary, highlight, accent):
  dest = []
  for y, row in enumerate(grid):
    for x, ch in enumerate(row):
      dest.append(color_for(ch, x, y, shadow, primary, highlight, accent))
  im = Image.new("RGBA", (W, H))
  im.putdata(dest)
  return finish(im)


def paint_modern(template_pixels, shadow, primary, highlight, accent):
  reds = [c[0] for c in template_pixels if is_body(c)]
  rmin, rmax = min(reds), max(reds)
  dest = []
  for i, c in enumerate(template_pixels):
    y = i // W
    if is_bg(c):
      dest.append(BG)
    elif is_black(c):
      dest.append(BLACK)
    elif is_yellow(c):
      dest.append(YELLOW)
    elif is_white(c):
      dest.append(WHITE)
    elif is_body(c):
      t = 0 if rmax == rmin else (c[0] - rmin) / (rmax - rmin)
      if accent and t > 0.62 and 15 <= y <= 27:
        dest.append((*accent, 255))
      elif t < 0.35:
        dest.append((*shadow, 255))
      elif t > 0.8:
        dest.append((*highlight, 255))
      else:
        dest.append(mix(shadow, primary, (t - 0.35) / 0.45))
    else:
      lum = (c[0] + c[1] + c[2]) / 3
      dest.append(BLACK if lum < 120 else BG)
  im = Image.new("RGBA", (W, H))
  im.putdata(dest)
  return finish(im)


def finish(im):
  p = im.load()
  for y in range(H):
    cols = [x for x in range(W) if p[x, y] != BG]
    if cols:
      p[cols[0], y] = BLACK
      p[cols[-1], y] = BLACK
      break
  for y in range(2):
    for x in range(W):
      p[x, y] = BG
  return im


def main():
  tmpl = Image.open(TEMPLATE).convert("RGBA")
  pixels = list(tmpl.getdata())
  written = 0
  for year, teams in SEASONS.items():
    grid = era_grid(year)
    for spec in teams:
      name = spec["name"]
      stem = car_sprite_id(year, name)
      shadow, primary, highlight, accent = livery_for(year, name, spec["color"])
      if year >= 2018:
        im = paint_modern(pixels, shadow, primary, highlight, accent)
      else:
        im = paint_grid(grid, shadow, primary, highlight, accent)
      assert im.size == (W, H), (stem, im.size)
      im.save(ASSETS / ("%s.png" % stem))
      written += 1
  print("wrote", written, "sprites")


if __name__ == "__main__":
  main()

from settings import *

class Camera:
  def __init__(self, player, screen, map_width, map_height):
    self.player = player
    self.screen = screen
    self.offset = pygame.math.Vector2()

    self.screen_width = screen.get_width()
    self.screen_height = screen.get_height()

    self.map_width = map_width
    self.map_height = map_height
  def Update(self):
    target_x = getattr(self.player, 'x', self.player.rect.centerx)
    target_y = getattr(self.player, 'y', self.player.rect.centery)
    self.offset.x = target_x - self.screen_width / 2
    self.offset.y = target_y - self.screen_height / 2
  def draw(self, all_sprites):
    view = pygame.Rect(
      int(self.offset.x) - TILE_SIZE,
      int(self.offset.y) - TILE_SIZE,
      self.screen_width + TILE_SIZE * 2,
      self.screen_height + TILE_SIZE * 2,
    )
    for sprite in all_sprites:
      if not view.colliderect(sprite.rect):
        continue
      draw_position = sprite.rect.topleft - self.offset
      self.screen.blit(sprite.image, draw_position)
  def draw_ui(self, ui_sprites):
    for sprite in ui_sprites:
      self.screen.blit(sprite.image, (sprite.rect.left, sprite.rect.top))

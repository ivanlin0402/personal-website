import os


def asset_path(*parts: str) -> str:
  """Resolve asset paths for desktop and pygbag (cwd is often the assets/ pack folder)."""
  joined = os.path.join(*parts)
  candidates = [
    joined,
    os.path.join("assets", *parts),
    os.path.join(*parts[1:]) if parts and parts[0] == "assets" else joined,
  ]
  for path in candidates:
    if os.path.exists(path):
      return path
  return joined


def load_font(size: int):
  import pygame

  font_file = asset_path("font", "Minecraftia-Regular.ttf")
  try:
    if os.path.exists(font_file):
      return pygame.font.Font(font_file, size)
  except Exception as exc:
    print("font load failed:", exc)
  return pygame.font.Font(None, size)

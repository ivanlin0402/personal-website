from settings import *

G = "grass"
R = "road"
W = "wall"

P1 = "p1"
P2 = "p2"

D = "drs"

# 定義你的基礎地圖元件符號（請確保 D 包含在你的賽道地表判定中）
# G = 草地, W = 牆壁/邊界, R = 正常賽道, D = DRS 賽道區域

MONZA = [
    # 行 0-2: 頂部草地與緩衝邊界
    [G]*80, [G]*80,
    [G,G,G,G,G,G,G,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G],
    
    # 行 3-5: 頂部大直道 往 第二減速彎 (Roggia Chicane) —— 【DRS 區域 1】
    # 將直道中後段的 R 替換為 D，保留前端出彎與後端入彎煞車區為 R
    [G,G,G,G,G,G,W,R,R,R,R,R,R,D,D,D,D,D,D,D,D,D,D,D,D,D,D,D,D,D,R,R,W,W,W,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,R,R,R,R,R,R,W,G,G,G,G,G,G,G],
    [G,G,G,G,G,G,W,R,R,R,R,R,R,D,D,D,D,D,D,D,D,D,D,D,D,D,D,D,D,D,R,R,R,R,R,R,W,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,R,R,R,R,R,R,R,R,W,G,G,G,G,G,G],
    [G,G,G,G,G,G,W,R,R,R,R,R,R,D,D,D,D,D,D,D,D,D,D,D,D,D,D,D,D,D,R,R,R,R,R,R,R,R,W,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,W,R,R,R,R,R,R,R,R,R,R,R,R,R,R,W,G,G,G,G,G],
    
    # 行 6-8: Roggia Chicane 的右折與左折細節 (具有斜度變化)
    [G,G,G,G,G,W,R,R,R,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,G,G,R,R,R,R,R,R,R,R,R,R,R,R,W,W,G,G,G,G,G,G,G,G,G,G,G,G,W,W,W,R,R,R,R,R,R,R,W,W,W,R,R,R,R,R,R,R,W,G,G,G,G,G],
    [G,G,G,G,G,W,R,R,R,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,G,G,G,W,W,R,R,R,R,R,R,R,R,R,R,R,W,W,G,G,G,G,G,G,G,W,W,W,R,R,R,R,R,R,R,W,W,W,G,G,G,W,R,R,R,R,R,R,R,W,G,G,G,G],
    [G,G,G,G,G,W,R,R,R,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,G,G,G,G,G,W,W,W,W,R,R,R,R,R,R,R,R,R,W,W,W,W,W,W,W,R,R,R,R,R,R,R,W,W,W,G,G,G,G,G,G,W,R,R,R,R,R,R,W,G,G,G,G,G],
    
    # 行 9-14: 左側起跑直道與排位 —— 【DRS 區域 2】
    # 起跑直道很長，扣除 P1/P2 起跑格與 1 號彎煞車區（R），中間全速衝刺段更換為 D
    [G,G,G,G,G,W,R,R,R,R,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,G,G,G,G,G,G,G,G,G,W,W,W,W,W,D,D,D,D,D,D,D,D,D,D,D,D,D,D,D,W,W,W,G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,R,R,W,G,G,G,G],
    [G,G,G,G,G,W,R,R,R,R,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,W,W,W,D,D,D,D,D,D,W,W,W,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,R,R,W,G,G,G,G],
    [G,G,G,G,G,W,R,R,R,R,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,D,D,D,D,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,R,R,W,G,G,G,G],
    [G,G,G,G,G,W,R,R,R,R,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,D,D,D,D,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,R,R,W,G,G,G,G],
    [G,G,G,G,G,W,R,R,R,R,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,R,R,W,G,G,G,G],
    [G,G,G,G,G,W,R,R,R,R,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,R,R,W,G,G,G,G],
    
    # 行 15-18: 第一減速彎 (Variante del Rettifilo) - 直角急折
    [G,G,G,G,G,W,R,R,R,W,W,W,W,W,W,G,G,G,G,G,G,G,G,G,G,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,R,R,W,G,G,G,G],
    [G,G,W,W,W,R,R,R,R,R,R,R,R,R,R,W,W,G,G,G,G,G,G,G,G,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,R,R,W,G,G,G,G],
    [G,G,W,R,R,R,R,R,R,R,R,R,R,R,R,R,R,W,G,G,G,G,G,G,G,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,W,R,R,R,R,R,R,W,G,G,G,G],
    [G,G,W,R,R,R,R,W,W,W,W,R,R,R,R,R,R,W,G,G,G,G,G,G,G,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,W,R,R,R,R,R,R,R,W,G,G,G,G,G],
    
    # 行 19-23: 中段Lesmo彎前的連接道 與 右側 Ascari 減速彎的對角斜線過渡
    [G,G,G,W,W,W,W,G,G,G,W,R,R,R,R,R,R,W,G,G,G,G,G,G,G,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,W,G,G,G,G,G,G,G,G,G,G,G,G,W,W,W,R,R,R,R,R,R,R,W,W,G,G,G,G,G,G],
    [G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,R,R,W,G,G,G,G,G,G,G,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,W,G,G,G,G,G,G,G,G,W,W,W,W,R,R,R,R,R,R,R,W,W,W,G,G,G,G,G,G,G,G],
    [G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,R,R,W,G,G,G,G,G,G,G,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,W,G,G,G,G,W,W,W,W,R,R,R,R,R,R,R,W,W,W,G,G,G,G,G,G,G,G,G,G,G,G],
    [G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,R,R,W,G,G,G,G,G,G,G,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,W,W,W,W,W,R,R,R,R,R,R,R,W,W,W,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G],
    [G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,R,R,W,G,G,G,G,G,G,G,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,R,R,R,R,R,R,R,R,W,W,W,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G],
    
    # 行 24-28: 進入底部 Parabolica 拋物線彎的前置直線段
    [G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,R,R,W,G,G,G,G,G,G,G,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,R,R,R,R,R,R,R,R,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G],
    [G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,R,R,W,G,G,G,G,G,G,G,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,W,W,W,R,R,R,R,R,R,R,R,R,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G],
    [G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,R,R,W,G,G,G,G,G,G,G,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,R,R,R,R,R,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G],
    [G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,R,R,W,G,G,G,G,G,G,G,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,R,R,R,R,R,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G],
    [G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,R,R,W,G,G,G,G,G,G,G,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,W,R,R,R,R,R,R,R,R,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G],
    
    # 行 29-32: 底部 Parabolica 拋物線巨型弧形大甩彎 (多段斜度銜接)
    [G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,R,R,W,W,W,W,W,W,W,W,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,R,R,R,W,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G],
    [G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,R,R,R,R,R,R,R,R,R,R,R,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,R,R,R,R,R,R,R,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G],
    [G,G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,R,R,R,R,R,R,R,R,R,R,R,R,R,R,R,R,R,R,R,R,R,R,R,R,R,R,R,R,R,R,R,R,R,R,R,R,R,R,R,W,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G],
    [G,G,G,G,G,G,G,G,G,G,G,G,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G],
    
    # 行 33-34: 底部草地緩衝
    [G]*80, [G]*80
]


NAME_TO_TRACK = {"monza":MONZA}

TRACK_CHECKPOINTS = {"monza":[pygame.Rect(1800, 1800, 900, 50),
                              pygame.Rect(13200, 3000, 1800, 300),
                              pygame.Rect(14630, 9300, 70, 300)]}

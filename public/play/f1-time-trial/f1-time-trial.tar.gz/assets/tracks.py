from settings import *

G = "grass"
R = "road"
W = "wall"

P1 = "p1"
P2 = "p2"

D = "drs"

# 定義你的基礎地圖元件符號（請確保 D 包含在你的賽道地表判定中）
# G = 草地, W = 牆壁/邊界, R = 正常賽道, D = DRS 賽道區域

MONZA_LAYOUT = [
    # 行 0-2: 頂部草地與緩衝邊界
    [G]*80, [G]*80,
    [G,G,G,G,G,G,G,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G],
    
    # 行 3-5: 頂部大直道 往 第二減速彎 (Roggia Chicane) —— 【DRS 區域 1】
    # 將直道中後段的 R 替換為 D，保留前端出彎與後端入彎煞車區為 R
    [G,G,G,G,G,G,W,R,R,R,R,R,R,D,D,D,D,D,D,D,D,D,D,D,D,D,D,D,D,D,R,R,W,W,W,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,R,R,R,R,R,R,W,G,G,G,G,G,G,G],
    [G,G,G,G,G,G,W,R,R,R,R,R,R,D,D,D,D,D,D,D,D,D,D,D,D,D,D,D,D,D,R,R,R,R,R,R,W,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,R,R,R,R,R,R,R,R,W,G,G,G,G,G,G],
    [G,G,G,G,G,G,W,R,R,R,R,R,R,D,D,D,D,D,D,D,D,D,D,D,D,D,D,D,D,D,R,R,R,R,R,R,R,R,W,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,W,R,R,R,R,R,R,R,R,R,R,R,R,R,R,W,G,G,G,G,G],
    
    # 行 6-8: Roggia Chicane 的右折與左折細節 (具有斜度變化)
    [G,G,G,G,G,W,R,R,R,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,G,G,R,R,R,R,R,R,R,R,R,R,R,R,W,W,G,G,G,G,G,G,G,G,G,G,G,G,W,W,W,R,R,R,R,R,R,R,W,W,W,R,R,R,R,R,R,R,W,G,G,G,G,G],
    [G,G,G,G,G,W,R,R,R,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,G,G,G,W,W,R,R,R,R,R,R,R,R,R,R,R,W,W,G,G,G,G,G,G,G,W,W,W,R,R,R,R,R,R,R,W,W,W,G,G,G,W,R,R,R,R,R,R,R,W,G,G,G,G],
    [G,G,G,G,G,W,R,R,R,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,G,G,G,G,G,W,W,W,W,R,R,R,R,R,R,R,R,R,W,W,W,W,W,W,W,R,R,R,R,R,R,R,W,W,W,G,G,G,G,G,G,W,R,R,R,R,R,R,W,G,G,G,G,G],
    
    # 行 9-14: 左側起跑直道與排位 —— 【DRS 區域 2】
    # 起跑直道很長，扣除 P1/P2 起跑格與 1 號彎煞車區（R），中間全速衝刺段更換為 D
    [G,G,G,G,G,W,R,R,R,R,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,G,G,G,G,G,G,G,G,G,W,W,W,W,W,D,D,D,D,D,D,D,D,D,D,D,D,D,D,D,W,W,W,G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,R,R,W,G,G,G,G],
    [G,G,G,G,G,W,R,R,R,R,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,W,W,W,D,D,D,D,D,D,W,W,W,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,R,R,W,G,G,G,G],
    [G,G,G,G,G,W,R,R,R,R,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,D,D,D,D,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,R,R,W,G,G,G,G],
    [G,G,G,G,G,W,R,R,R,R,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,D,D,D,D,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,R,R,W,G,G,G,G],
    [G,G,G,G,G,W,R,R,R,R,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,R,R,W,G,G,G,G],
    [G,G,G,G,G,W,R,R,R,R,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,R,R,W,G,G,G,G],
    
    # 行 15-18: 第一減速彎 (Variante del Rettifilo) - 直角急折
    [G,G,G,G,G,W,R,R,R,W,W,W,W,W,W,G,G,G,G,G,G,G,G,G,G,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,R,R,W,G,G,G,G],
    [G,G,W,W,W,R,R,R,R,R,R,R,R,R,R,W,W,G,G,G,G,G,G,G,G,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,R,R,W,G,G,G,G],
    [G,G,W,R,R,R,R,R,R,R,R,R,R,R,R,R,R,W,G,G,G,G,G,G,G,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,W,R,R,R,R,R,R,W,G,G,G,G],
    [G,G,W,R,R,R,R,W,W,W,W,R,R,R,R,R,R,W,G,G,G,G,G,G,G,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,W,R,R,R,R,R,R,R,W,G,G,G,G,G],
    
    # 行 19-23: 中段Lesmo彎前的連接道 與 右側 Ascari 減速彎的對角斜線過渡
    [G,G,G,W,W,W,W,G,G,G,W,R,R,R,R,R,R,W,G,G,G,G,G,G,G,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,W,G,G,G,G,G,G,G,G,G,G,G,G,W,W,W,R,R,R,R,R,R,R,W,W,G,G,G,G,G,G],
    [G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,R,R,W,G,G,G,G,G,G,G,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,W,G,G,G,G,G,G,G,G,W,W,W,W,R,R,R,R,R,R,R,W,W,W,G,G,G,G,G,G,G,G],
    [G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,R,R,W,G,G,G,G,G,G,G,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,W,G,G,G,G,W,W,W,W,R,R,R,R,R,R,R,W,W,W,G,G,G,G,G,G,G,G,G,G,G,G],
    [G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,R,R,W,G,G,G,G,G,G,G,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,W,W,W,W,W,R,R,R,R,R,R,R,W,W,W,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G],
    [G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,R,R,W,G,G,G,G,G,G,G,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,R,R,R,R,R,R,R,R,W,W,W,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G],
    
    # 行 24-28: 進入底部 Parabolica 拋物線彎的前置直線段
    [G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,R,R,W,G,G,G,G,G,G,G,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,R,R,R,R,R,R,R,R,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G],
    [G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,R,R,W,G,G,G,G,G,G,G,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,W,W,W,R,R,R,R,R,R,R,R,R,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G],
    [G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,R,R,W,G,G,G,G,G,G,G,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,R,R,R,R,R,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G],
    [G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,R,R,W,G,G,G,G,G,G,G,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,R,R,R,R,R,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G],
    [G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,R,R,W,G,G,G,G,G,G,G,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,W,R,R,R,R,R,R,R,R,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G],
    
    # 行 29-32: 底部 Parabolica 拋物線巨型弧形大甩彎 (多段斜度銜接)
    [G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,R,R,W,W,W,W,W,W,W,W,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,R,R,R,W,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G],
    [G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,R,R,R,R,R,R,R,R,R,R,R,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,R,R,R,R,R,R,R,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G],
    [G,G,G,G,G,G,G,G,G,G,G,W,R,R,R,R,R,R,R,R,R,R,R,R,R,R,R,R,R,R,R,R,R,R,R,R,R,R,R,R,R,R,R,R,R,R,R,R,R,R,R,R,R,R,R,W,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G],
    [G,G,G,G,G,G,G,G,G,G,G,G,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,W,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G],
    
    # 行 33-34: 底部草地緩衝
    [G]*80, [G]*80
]


TRACK_SCALE = 3

# Centerline in the original 80×35 layout (col, row). Arcs are stamped
# as disks so Rettifilo, Roggia, Ascari and Parabolica read as F1 corners.
MONZA_LINE = [
  (7.5, 4.2), (7.5, 8.0), (7.5, 13.4),
  (6.2, 15.0), (4.4, 16.2), (5.2, 17.4), (8.6, 17.55), (12.8, 17.2), (13.6, 18.8),
  (13.5, 23.0), (13.5, 28.0),
  (15.8, 30.2), (21.0, 31.15), (28.5, 31.35), (36.5, 31.3), (44.0, 30.7), (49.4, 28.8), (51.4, 26.2),
  (51.2, 22.5), (48.4, 18.0), (47.0, 13.5), (47.0, 10.4),
  (50.2, 8.6), (55.5, 7.2), (61.5, 5.9), (67.2, 4.8), (70.2, 4.2),
  (64.0, 3.85), (52.0, 3.8), (38.0, 3.8), (24.0, 3.85), (14.0, 4.1), (9.2, 4.6),
  (7.6, 5.6),
]


def _upsample_mask(layout, scale, pred):
  out = []
  for row in layout:
    built = []
    for cell in row:
      built.extend([pred(cell)] * scale)
    for _ in range(scale):
      out.append(list(built))
  return out


def _catmull_point(p0, p1, p2, p3, t):
  t2 = t * t
  t3 = t2 * t
  return (
    0.5 * ((2 * p1[0]) + (-p0[0] + p2[0]) * t + (2 * p0[0] - 5 * p1[0] + 4 * p2[0] - p3[0]) * t2 + (-p0[0] + 3 * p1[0] - 3 * p2[0] + p3[0]) * t3),
    0.5 * ((2 * p1[1]) + (-p0[1] + p2[1]) * t + (2 * p0[1] - 5 * p1[1] + 4 * p2[1] - p3[1]) * t2 + (-p0[1] + 3 * p1[1] - 3 * p2[1] + p3[1]) * t3),
  )


def _smooth_loop(points, steps=12):
  n = len(points)
  out = []
  for i in range(n):
    p0 = points[(i - 1) % n]
    p1 = points[i]
    p2 = points[(i + 1) % n]
    p3 = points[(i + 2) % n]
    for s in range(steps):
      out.append(_catmull_point(p0, p1, p2, p3, s / steps))
  return out


def _stamp_disk(grid, cy, cx, radius, value):
  h = len(grid)
  w = len(grid[0])
  r0 = max(0, int(cy - radius) - 1)
  r1 = min(h - 1, int(cy + radius) + 1)
  c0 = max(0, int(cx - radius) - 1)
  c1 = min(w - 1, int(cx + radius) + 1)
  r2 = radius * radius
  for r in range(r0, r1 + 1):
    dy = r + 0.5 - cy
    for c in range(c0, c1 + 1):
      dx = c + 0.5 - cx
      if dy * dy + dx * dx <= r2:
        grid[r][c] = value


def refine_track(layout, scale=TRACK_SCALE):
  """Same world size, 3× more tiles, constant-width curved ribbon."""
  h = len(layout) * scale
  w = len(layout[0]) * scale
  grid = [[G] * w for _ in range(h)]
  old_drs = _upsample_mask(layout, scale, lambda cell: cell == D)
  old_wall = _upsample_mask(layout, scale, lambda cell: cell == W)

  line = [(c * scale + (scale - 1) / 2, r * scale + (scale - 1) / 2) for c, r in MONZA_LINE]
  radius = 2.05 * scale
  for cx, cy in _smooth_loop(line, steps=16):
    _stamp_disk(grid, cy, cx, radius, R)

  # Keep chicane islands / infield walls that sat between two road sides
  ch = len(layout)
  cw = len(layout[0])
  for rr in range(ch):
    for cc in range(cw):
      if layout[rr][cc] != W:
        continue
      n = rr > 0 and layout[rr - 1][cc] in (R, D)
      s = rr + 1 < ch and layout[rr + 1][cc] in (R, D)
      e = cc + 1 < cw and layout[rr][cc + 1] in (R, D)
      west = cc > 0 and layout[rr][cc - 1] in (R, D)
      if not ((n and s) or (e and west)):
        continue
      for r in range(rr * scale, (rr + 1) * scale):
        for c in range(cc * scale, (cc + 1) * scale):
          grid[r][c] = G

  for r in range(h):
    for c in range(w):
      if grid[r][c] == R and old_drs[r][c]:
        grid[r][c] = D

  out = [[G] * w for _ in range(h)]
  for r in range(h):
    for c in range(w):
      cell = grid[r][c]
      if cell in (R, D):
        out[r][c] = cell
        continue
      near_road = False
      for dr in (-1, 0, 1):
        for dc in (-1, 0, 1):
          if dr == 0 and dc == 0:
            continue
          rr, cc = r + dr, c + dc
          if 0 <= rr < h and 0 <= cc < w and grid[rr][cc] in (R, D):
            near_road = True
            break
        if near_road:
          break
      if near_road or old_wall[r][c]:
        out[r][c] = W
  return out


MONZA = refine_track(MONZA_LAYOUT)

NAME_TO_TRACK = {"monza": MONZA}

TRACK_CHECKPOINTS = {"monza":[pygame.Rect(1800, 1800, 900, 50),
                              pygame.Rect(13200, 3000, 1800, 300),
                              pygame.Rect(14630, 9300, 70, 300)]}

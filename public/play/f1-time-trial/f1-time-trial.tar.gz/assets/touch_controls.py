"""On-screen multi-touch controls for phones / tablets (and web builds)."""

from __future__ import annotations

import sys

from settings import *

# Continuous actions (held while finger stays down)
HOLD_ACTIONS = ("left", "right", "accel", "brake", "drs")
# One-shot actions (fire once per press)
TAP_ACTIONS = ("gear_up", "gear_down")


def is_touch_ui_enabled() -> bool:
  """Show pads on web builds; desktop keeps keyboard-only UI."""
  try:
    import platform

    if platform.system() == "Emscripten":
      return True
  except Exception:
    pass
  return sys.platform in ("emscripten", "wasm")


class TouchControls:
  def __init__(self):
    self.enabled = is_touch_ui_enabled()
    self.manual_gears = False
    self.held: set[str] = set()
    self.taps: set[str] = set()
    self._pointer_action: dict[object, str] = {}
    self._layout_buttons()

  def set_manual_gears(self, enabled: bool) -> None:
    self.manual_gears = enabled
    self._layout_buttons()

  def _layout_buttons(self) -> None:
    pad = 14
    size = 78
    gap = 12
    bottom = WINDOW_HEIGHT - pad - size

    # Steer — bottom left
    self.buttons = {
      "left": pygame.Rect(pad, bottom, size, size),
      "right": pygame.Rect(pad + size + gap, bottom, size, size),
      # Drive — bottom right
      "brake": pygame.Rect(WINDOW_WIDTH - pad - size * 2 - gap, bottom, size, size),
      "accel": pygame.Rect(WINDOW_WIDTH - pad - size, bottom - 20, size, size + 20),
      "drs": pygame.Rect(WINDOW_WIDTH - pad - size, bottom - size - gap - 20, size, size),
    }

    if self.manual_gears:
      gear_x = WINDOW_WIDTH - pad - size * 3 - gap * 2
      self.buttons["gear_up"] = pygame.Rect(gear_x, bottom - size - gap, size, size)
      self.buttons["gear_down"] = pygame.Rect(gear_x, bottom, size, size)
    else:
      self.buttons.pop("gear_up", None)
      self.buttons.pop("gear_down", None)

    self.labels = {
      "left": "<",
      "right": ">",
      "accel": "GAS",
      "brake": "BRK",
      "drs": "DRS",
      "gear_up": "+",
      "gear_down": "-",
    }

  def _event_pos(self, event) -> tuple[float, float] | None:
    if event.type in (pygame.FINGERDOWN, pygame.FINGERUP, pygame.FINGERMOTION):
      return event.x * WINDOW_WIDTH, event.y * WINDOW_HEIGHT
    if event.type in (pygame.MOUSEBUTTONDOWN, pygame.MOUSEBUTTONUP, pygame.MOUSEMOTION):
      if hasattr(event, "button") and event.type != pygame.MOUSEMOTION and event.button != 1:
        return None
      if event.type == pygame.MOUSEMOTION and not (event.buttons and event.buttons[0]):
        return None
      return float(event.pos[0]), float(event.pos[1])
    return None

  def _pointer_id(self, event) -> object | None:
    if event.type in (pygame.FINGERDOWN, pygame.FINGERUP, pygame.FINGERMOTION):
      return ("finger", event.finger_id)
    if event.type in (pygame.MOUSEBUTTONDOWN, pygame.MOUSEBUTTONUP, pygame.MOUSEMOTION):
      return "mouse"
    return None

  def _action_at(self, pos: tuple[float, float]) -> str | None:
    point = (int(pos[0]), int(pos[1]))
    for name, rect in self.buttons.items():
      if rect.collidepoint(point):
        return name
    return None

  def _rebuild_held(self) -> None:
    self.held = {
      action
      for action in self._pointer_action.values()
      if action in HOLD_ACTIONS
    }

  def handle_event(self, event) -> None:
    if not self.enabled:
      return

    pid = self._pointer_id(event)
    pos = self._event_pos(event)
    if pid is None:
      return

    is_down = event.type in (pygame.FINGERDOWN, pygame.MOUSEBUTTONDOWN)
    is_up = event.type in (pygame.FINGERUP, pygame.MOUSEBUTTONUP)
    is_move = event.type in (pygame.FINGERMOTION, pygame.MOUSEMOTION)

    if is_down and pos is not None:
      action = self._action_at(pos)
      if action is None:
        return
      self._pointer_action[pid] = action
      if action in TAP_ACTIONS:
        self.taps.add(action)
      self._rebuild_held()
      return

    if is_up:
      if pid in self._pointer_action:
        del self._pointer_action[pid]
        self._rebuild_held()
      return

    if is_move and pos is not None and pid in self._pointer_action:
      action = self._action_at(pos)
      prev = self._pointer_action.get(pid)
      if action is None:
        del self._pointer_action[pid]
        self._rebuild_held()
      elif action != prev:
        self._pointer_action[pid] = action
        if action in TAP_ACTIONS and action not in self.held:
          self.taps.add(action)
        self._rebuild_held()

  def consume_taps(self) -> set[str]:
    taps = set(self.taps)
    self.taps.clear()
    return taps

  def holding(self, action: str) -> bool:
    return action in self.held

  def draw(self, screen: pygame.Surface) -> None:
    if not self.enabled:
      return

    overlay = pygame.Surface((WINDOW_WIDTH, WINDOW_HEIGHT), pygame.SRCALPHA)
    font = pygame.font.Font(None, 28)

    for name, rect in self.buttons.items():
      active = name in self.held or name in self.taps
      fill = (255, 255, 255, 90) if active else (255, 255, 255, 45)
      border = (255, 255, 255, 180) if active else (255, 255, 255, 110)
      pygame.draw.rect(overlay, fill, rect, border_radius=14)
      pygame.draw.rect(overlay, border, rect, width=2, border_radius=14)

      label = self.labels.get(name, name)
      text = font.render(label, True, (255, 255, 255))
      text_rect = text.get_rect(center=rect.center)
      overlay.blit(text, text_rect)

    screen.blit(overlay, (0, 0))

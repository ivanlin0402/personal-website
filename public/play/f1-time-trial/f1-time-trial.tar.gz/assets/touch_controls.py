"""On-screen multi-touch controls for phones / tablets (web builds)."""

from __future__ import annotations

import platform

from settings import *
from assets_util import load_font

HOLD_ACTIONS = ("left", "right", "accel", "brake", "drs")
TAP_ACTIONS = ("gear_up", "gear_down", "leaderboard")

FINGER_DOWN = getattr(pygame, "FINGERDOWN", None)
FINGER_UP = getattr(pygame, "FINGERUP", None)
FINGER_MOTION = getattr(pygame, "FINGERMOTION", None)
FINGER_EVENTS = tuple(e for e in (FINGER_DOWN, FINGER_UP, FINGER_MOTION) if e is not None)


def is_touch_ui_enabled() -> bool:
  try:
    if platform.system() == "Emscripten":
      return True
  except Exception:
    pass
  return False


class TouchControls:
  def __init__(self):
    self.enabled = is_touch_ui_enabled()
    self.manual_gears = False
    self.held = set()
    self.taps = set()
    self._pointer_action = {}
    self._font = None
    self._layout_buttons()

  def _get_font(self):
    if self._font is None:
      self._font = load_font(22)
    return self._font

  def set_manual_gears(self, enabled: bool) -> None:
    self.manual_gears = enabled
    self._layout_buttons()

  def _layout_buttons(self) -> None:
    pad = 14
    size = 78
    gap = 12
    bottom = WINDOW_HEIGHT - pad - size

    self.buttons = {
      "left": pygame.Rect(pad, bottom, size, size),
      "right": pygame.Rect(pad + size + gap, bottom, size, size),
      "brake": pygame.Rect(WINDOW_WIDTH - pad - size * 2 - gap, bottom, size, size),
      "accel": pygame.Rect(WINDOW_WIDTH - pad - size, bottom - 20, size, size + 20),
      "drs": pygame.Rect(WINDOW_WIDTH - pad - size, bottom - size - gap - 20, size, size),
      # Leaderboard toggle (top-left, clear of lap HUD)
      "leaderboard": pygame.Rect(WINDOW_WIDTH // 2 - 36, pad, 72, 40),
    }

    if self.manual_gears:
      gear_x = WINDOW_WIDTH - pad - size * 3 - gap * 2
      self.buttons["gear_up"] = pygame.Rect(gear_x, bottom - size - gap, size, size)
      self.buttons["gear_down"] = pygame.Rect(gear_x, bottom, size, size)
    else:
      self.buttons.pop("gear_up", None)
      self.buttons.pop("gear_down", None)

    self.labels = {
      "left": "<",
      "right": ">",
      "accel": "GAS",
      "brake": "BRK",
      "drs": "DRS",
      "gear_up": "+",
      "gear_down": "-",
      "leaderboard": "LB",
    }

  def _is_finger(self, event) -> bool:
    return bool(FINGER_EVENTS) and event.type in FINGER_EVENTS

  def _event_pos(self, event):
    if self._is_finger(event):
      return event.x * WINDOW_WIDTH, event.y * WINDOW_HEIGHT
    if event.type in (pygame.MOUSEBUTTONDOWN, pygame.MOUSEBUTTONUP, pygame.MOUSEMOTION):
      if event.type != pygame.MOUSEMOTION and getattr(event, "button", 1) != 1:
        return None
      if event.type == pygame.MOUSEMOTION and not (event.buttons and event.buttons[0]):
        return None
      return float(event.pos[0]), float(event.pos[1])
    return None

  def _pointer_id(self, event):
    if self._is_finger(event):
      return ("finger", event.finger_id)
    if event.type in (pygame.MOUSEBUTTONDOWN, pygame.MOUSEBUTTONUP, pygame.MOUSEMOTION):
      return "mouse"
    return None

  def _action_at(self, pos):
    point = (int(pos[0]), int(pos[1]))
    for name, rect in self.buttons.items():
      if rect.collidepoint(point):
        return name
    return None

  def _rebuild_held(self) -> None:
    self.held = {
      action
      for action in self._pointer_action.values()
      if action in HOLD_ACTIONS
    }

  def handle_event(self, event) -> None:
    if not self.enabled:
      return

    pid = self._pointer_id(event)
    pos = self._event_pos(event)
    if pid is None:
      return

    is_down = event.type == pygame.MOUSEBUTTONDOWN or event.type == FINGER_DOWN
    is_up = event.type == pygame.MOUSEBUTTONUP or event.type == FINGER_UP
    is_move = event.type == pygame.MOUSEMOTION or event.type == FINGER_MOTION

    if is_down and pos is not None:
      action = self._action_at(pos)
      if action is None:
        return
      self._pointer_action[pid] = action
      if action in TAP_ACTIONS:
        self.taps.add(action)
      self._rebuild_held()
      return

    if is_up:
      if pid in self._pointer_action:
        del self._pointer_action[pid]
        self._rebuild_held()
      return

    if is_move and pos is not None and pid in self._pointer_action:
      action = self._action_at(pos)
      if action is None:
        del self._pointer_action[pid]
        self._rebuild_held()
      elif action != self._pointer_action.get(pid):
        self._pointer_action[pid] = action
        if action in TAP_ACTIONS:
          self.taps.add(action)
        self._rebuild_held()

  def consume_taps(self):
    taps = set(self.taps)
    self.taps.clear()
    return taps

  def holding(self, action: str) -> bool:
    return action in self.held

  def draw(self, screen) -> None:
    if not self.enabled:
      return

    try:
      font = self._get_font()
      for name, rect in self.buttons.items():
        active = name in self.held
        pad = pygame.Surface((rect.width, rect.height), pygame.SRCALPHA)
        fill = (255, 255, 255, 100) if active else (255, 255, 255, 55)
        pad.fill(fill)
        screen.blit(pad, rect.topleft)
        pygame.draw.rect(screen, (255, 255, 255), rect, 2)

        label = self.labels.get(name, name)
        text = font.render(label, True, (255, 255, 255))
        screen.blit(text, text.get_rect(center=rect.center))
    except Exception as exc:
      print("touch draw failed:", exc)
      self.enabled = False

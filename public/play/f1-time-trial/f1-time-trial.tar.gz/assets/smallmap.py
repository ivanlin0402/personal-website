from settings import *
from tracks import *
from smallmaptile import SmallMapTile

class SmallMap(pygame.sprite.Sprite):
  def __init__(self, track_name, car, all_sprites, ui_sprites):
    super().__init__(ui_sprites)
    self.image = pygame.Surface((SMALLMAP_WIDTH, SMALLMAP_HEIGHT))
    self.rect = self.image.get_rect(topleft=SMALLMAP_POS)
    self.car = car
    self.car_pos = self.car.position
    self.track = NAME_TO_TRACK[track_name]
    self.map_width = len(self.track[0])
    self.map_height = len(self.track)
    self.ui_sprites = ui_sprites
    self.tile_width = self.image.get_width() // self.map_width
    self.tile_height = self.image.get_height() // self.map_height
    self.CreateMap()
    
    car_w = max(5, self.car.rect.width / TILE_SIZE * self.tile_width)
    car_h = max(5, self.car.rect.height / TILE_SIZE * self.tile_height)
    self.map_car_sprite = SmallMapTile((0, 0), "car", car_w, car_h, self.ui_sprites)

  def CreateMap(self):
    for row_index, row in enumerate(self.track):
      for col_index, tile_id in enumerate(row):
        x = col_index * self.tile_width
        y = row_index * self.tile_height
        SmallMapTile((x, y), tile_id, 
                     self.tile_width,
                     self.tile_height,
                     self.ui_sprites)
  def DrawCar(self):
    x = (self.car_pos.x / TILE_SIZE) * self.tile_width
    y = (self.car_pos.y / TILE_SIZE) * self.tile_height
    x -= self.map_car_sprite.rect.width / 2
    y -= self.map_car_sprite.rect.height / 2
    self.map_car_sprite.UpdatePosition((x, y))
  def Update(self):
    self.DrawCar()

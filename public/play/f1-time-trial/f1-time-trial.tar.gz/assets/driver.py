from settings import *

class Driver:
  def __init__(self, name, pace, tire_management):
    self.name = name
    self.pace = pace
    self.tire_management = tire_management

from settings import *
from tire import Tire
from wing import Wing
from assets_util import asset_path


class Car(pygame.sprite.Sprite):
  def __init__(self, pos, name, engine):
    super().__init__()
    self.name = name
    image_path = asset_path("assets", f"{self.name}.png")
    if not __import__("os").path.exists(image_path):
      image_path = asset_path(f"{self.name}.png")
    print("loading car image:", image_path)
    raw = pygame.image.load(image_path)
    try:
      raw = raw.convert_alpha()
    except Exception:
      try:
        raw = raw.convert()
      except Exception:
        pass
    self.original_image = pygame.transform.scale(raw, CAR_SIZE)
    self.image = self.original_image.copy()
    self.rect = self.image.get_rect(topleft=pos)

    self.position = pygame.math.Vector2(pos)
    self.old_position = pygame.math.Vector2(self.position)

    self.hitbox_radius = CAR_HITBOX_RADIUS
    self.offset_distance = CAR_HITBOX_OFFSET_DISTANCE
    self.hitbox_circles = []
    self.speed = 0
    self.angle = 0
    self.direction = 0
    self.steering_angle = 0
    self.wheelbase = CAR_WHEELBASE
    self.engine = engine
    self.engine.gear = getattr(engine, "gear", "auto")

    self.UpdateHitboxCircles()
  def AddGroup(self, all_sprites, obstacle_sprites, drs_sprites):
    all_sprites.add(self)
    self.obstacle_sprites = obstacle_sprites
    self.drs_sprites = drs_sprites
  def AddDriver(self, driver):
    self.driver = driver
    driver.car = self
    self.pace_factor = 0.98 + (driver.pace - 100) * 0.4
    self.tire_management_factor = 1.3 - (driver.tire_management / 100) * 0.6
  def AddGear(self, gear):
    self.gear = gear
    self.engine.gear = gear
  def PartSetup(self, tire_type, front_wing_angle, rear_wing_angle):
    self.tires = Tire(tire_type)
    self.front_wing = Wing(front_wing_angle, False)
    self.rear_wing = Wing(rear_wing_angle, True)
    self.is_drs_zone = False
  def HandleInput(self):
    keys = pygame.key.get_pressed()
    self.engine.UpdateRPM(self.speed)

    current_grip = self.tires.get_current_grip()
    total_drag = self.front_wing.get_drag() + self.rear_wing.get_drag()
    total_downforce = self.front_wing.get_downforce() + self.rear_wing.get_downforce()
    base_max_steer = BASE_MAX_STEER
    downforce_bonus = (self.speed * total_downforce) * DOWNFORCE_STEER_BONUS_FACTOR
    max_steer = base_max_steer * current_grip + downforce_bonus
    max_steer = min(STEER_LIMIT_MAX, max(STEER_LIMIT_MIN, max_steer))
    
    if keys[pygame.K_RIGHT]:
      self.steering_angle = max(-max_steer, self.steering_angle - STEER_SPEED)
    elif keys[pygame.K_LEFT]:
      self.steering_angle = min(max_steer, self.steering_angle + STEER_SPEED)
    else:
      if abs(self.steering_angle) < STEER_DEADZONE:
        self.steering_angle = 0
      else:
        if self.steering_angle > 0:
          self.steering_angle -= STEER_RETURN_SPEED
        elif self.steering_angle < 0:
          self.steering_angle += STEER_RETURN_SPEED
    acceleration_penalty = total_drag * DRAG_ACCEL_PENALTY_FACTOR
    dynamic_engine_power = self.engine.GetDynamicAcceleration() * self.pace_factor
    final_acceleration = max(MIN_ACCELERATION, dynamic_engine_power - acceleration_penalty)
    if keys[pygame.K_x]:
      if self.rear_wing.drs_open:
        current_gear_max_speed = self.engine.drs_max_speed * self.engine.gear_limits[self.engine.current_gear]
      else:
        current_gear_max_speed = self.engine.max_speed * self.engine.gear_limits[self.engine.current_gear]
      self.speed = min(current_gear_max_speed, self.speed + final_acceleration)
    elif keys[pygame.K_z]:
      self.speed = self.speed - BRAKE_FORCE
      self.rear_wing.drs_open = False
    else:
      coast_decay = BASE_COAST_DECAY - (total_drag * DRAG_COAST_FACTOR)
      self.speed = self.speed * max(MAX_COAST_DECAY, coast_decay)

      if abs(self.speed) < 0.1:
        self.speed = 0
    
    if keys[pygame.K_SPACE]:
      self.DRSCheck()

    
    
    is_turning = abs(self.steering_angle) > TIRE_WEAR_TURN_THRESHOLD
    self.tires.UpdateWear(self.speed, is_turning, self.tire_management_factor)

  def HandlePhysics(self):
    self.old_position.x = self.position.x
    self.old_position.y = self.position.y
    if (self.speed != 0) and abs(self.steering_angle) > PHYSICS_STEER_THRESHOLD:
      steer_rad = math.radians(self.steering_angle)
      angular_vel = (self.speed/self.wheelbase) * math.tan(steer_rad)
      self.direction += math.degrees(angular_vel)
    vel = pygame.math.Vector2(0, -self.speed)
    vel.rotate_ip(-self.direction)
    self.position += vel

    self.rect.center = (int(self.position.x), int(self.position.y))
    self.UpdateHitboxCircles()
  def UpdateHitboxCircles(self):
    forward_vector = pygame.math.Vector2(0, -1)
    forward_vector.rotate_ip(-self.direction)
    front_center = self.position + forward_vector * self.offset_distance
    center_center = self.position.copy()
    back_center = self.position - forward_vector * self.offset_distance
    self.hitbox_circles = [front_center, center_center, back_center]
  def HandleCollision(self):
    for obstacle in self.obstacle_sprites:
      collision_detected = False
      target_rect = obstacle.hitbox
      for idx, circle_center in enumerate(self.hitbox_circles):
        if self.CheckCircleRectCollision(circle_center, self.hitbox_radius, target_rect):
          collision_detected = True
          if abs(self.speed) > WING_DAMAGE_SPEED_THRESHOLD:
            damage_amount = abs(self.speed) * WING_DAMAGE_FACTOR
            if idx == 0:
              self.front_wing.take_damage(damage_amount)
            elif idx == 2:
              self.rear_wing.take_damage(damage_amount)
          break
      if collision_detected:
        self.position.x = self.old_position.x
        self.position.y = self.old_position.y
        self.rect.center = (int(self.position.x), int(self.position.y))
        self.UpdateHitboxCircles()
        if self.speed > HIGH_SPEED_COLLISION_THRESHOLD:
          self.speed  *= - HIGH_SPEED_BOUNCE
        else:
          self.speed *= - LOW_SPEED_BOUNCE
        break
    for drs in self.drs_sprites:
      if self.rect.colliderect(drs.hitbox):
        self.is_drs_zone = True
  def CheckCircleRectCollision(self, circle_center, radius, rect):
    closest_x = max(rect.left, min(circle_center.x, rect.right))
    closest_y = max(rect.top, min(circle_center.y, rect.bottom))
    closest_point = pygame.math.Vector2(closest_x, closest_y)
    return circle_center.distance_to(closest_point) < radius
  def ImageUpdate(self):
    old_center = self.rect.center
    self.image = pygame.transform.rotate(self.original_image, self.direction)
    pixel_array = pygame.PixelArray(self.image)
    for color in ASSET_COLORS:
      mapped_color = self.image.map_rgb(color)
      pixel_array.replace(mapped_color, (0, 0, 0, 0))
    pixel_array.close()
    self.rect = self.image.get_rect(center=self.position)
    self.UpdateHitboxCircles()
  def DRSCheck(self):
    if self.is_drs_zone:
      self.rear_wing.drs_open = True
    else:
      self.rear_wing.drs_open = False
    
  def Update(self):
    self.HandleInput()
    self.HandlePhysics()
    self.ImageUpdate()
    self.HandleCollision()

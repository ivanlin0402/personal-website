import asyncio
import platform
import traceback

from settings import *
from world import World
from camera import Camera
from smallmap import SmallMap
from laptimer import LapTimer
from tracks import *
from textshower import Text
from menu import Menu
from car import Car
from engine import Engine
from touch_controls import TouchControls
from leaderboard import Leaderboard
from assets_util import load_font


IS_WEB = platform.system() == "Emscripten"


class Game:
  def __init__(self, screen):
    self.screen = screen
    self.clock = pygame.time.Clock()
    self.running = True
    self.all_sprites = pygame.sprite.Group()
    self.obstacle_sprites = pygame.sprite.Group()
    self.drs_sprites = pygame.sprite.Group()
    self.ui_sprites = pygame.sprite.Group()
    self.touch = TouchControls()
    self.leaderboard = Leaderboard()
    self.team_name = ""
    self.driver_name = ""
    self.year = None
    self.ready = False

  async def _show_message(self, lines, frames=30):
    font = load_font(36)
    for _ in range(frames):
      self.screen.fill(BLACK)
      y = WINDOW_HEIGHT // 2 - 20 * len(lines)
      for line in lines:
        surf = font.render(line, True, WHITE)
        self.screen.blit(surf, (WINDOW_WIDTH // 2 - surf.get_width() // 2, y))
        y += 40
      pygame.display.flip()
      await asyncio.sleep(0)

  async def _setup_race(self, team, driver, gear):
    await self._show_message(["Loading track..."], frames=2)
    self.gear = gear
    self.year = getattr(team, "year", None)
    self.team_name = team.name
    self.driver_name = driver.name
    self.touch.set_manual_gears(gear == "manual")
    self.world = World("monza", self.all_sprites, self.obstacle_sprites, self.drs_sprites)
    await self.world.CreateTrack()

    await self._show_message(["Loading car..."], frames=2)
    engine = Engine(
      team.engine_name,
      30 if team.engine_name == "V8" else 29,
      50 if team.engine_name == "V8" else 46,
      0.19 if team.engine_name == "V8" else 0.21,
    )
    self.car = Car((3300, 4000), team.car_model, engine)
    self.car.AddDriver(driver)
    self.car.AddGroup(self.all_sprites, self.obstacle_sprites, self.drs_sprites)
    self.car.PartSetup("soft", 28, 25)
    self.car.AddGear(self.gear)

    self.camera = Camera(
      self.car,
      self.screen,
      len(self.world.track[0]) * TILE_SIZE,
      len(self.world.track) * TILE_SIZE,
    )
    self.smallmap = SmallMap("monza", self.car, self.ui_sprites, self.ui_sprites)
    self.laptimer = LapTimer(TRACK_CHECKPOINTS["monza"])
    hud_y = 430 if self.touch.enabled else 550
    self.text_gear = Text((650, hud_y), self.car.engine.current_gear, 40, WHITE)
    self.text_speed = Text((700, hud_y), self.car.speed, 40, WHITE)
    self.ready = True
    year_bit = "'{:02d}  ".format(self.year % 100) if self.year else ""
    if self.touch.enabled:
      tip = "Pads to drive  ·  LB for leaderboard"
    else:
      tip = "X/Z/arrows/SPACE  ·  Tab for leaderboard"
    await self._show_message(
      ["Ready!", "{}{}  {}".format(year_bit, self.team_name, self.driver_name), tip],
      frames=40,
    )

  def HandleInput(self):
    for event in pygame.event.get():
      if event.type == pygame.QUIT:
        self.running = False
        return
      self.touch.handle_event(event)
      if event.type == pygame.KEYDOWN:
        if event.key == pygame.K_TAB:
          self.leaderboard.toggle()
        elif self.gear == "manual":
          if event.key == pygame.K_UP:
            self.car.engine.ShiftUp(self.car.speed)
          if event.key == pygame.K_DOWN:
            self.car.engine.ShiftDown(self.car.speed)

    taps = self.touch.consume_taps()
    if "leaderboard" in taps:
      self.leaderboard.toggle()
    if self.gear == "manual":
      if "gear_up" in taps:
        self.car.engine.ShiftUp(self.car.speed)
      if "gear_down" in taps:
        self.car.engine.ShiftDown(self.car.speed)

  def Draw(self):
    self.screen.fill(GREEN)
    self.camera.draw(self.all_sprites)
    self.camera.draw_ui(self.ui_sprites)
    self.laptimer.Draw(self.screen)
    for tc in TRACK_CHECKPOINTS["monza"]:
      pygame.draw.rect(self.screen, (255, 0, 0), tc, 0)
    self.text_gear.Draw(self.screen)
    self.text_speed.Draw(self.screen)
    self.touch.draw(self.screen)
    self.leaderboard.draw(self.screen)
    pygame.display.flip()

  def Update(self):
    self.HandleInput()
    if not self.running:
      return
    # Keep driving while the list is open so Tab is only a overlay toggle
    self.car.Update(self.touch)
    for sprite in self.all_sprites:
      if sprite is self.car:
        continue
      sprite.Update()
    for sprite in self.ui_sprites:
      sprite.Update()
    if self.laptimer.Update(self.car, self.dt):
      # Only the completed last lap is submitted
      self.leaderboard.submit(
        self.team_name,
        self.driver_name,
        self.laptimer.last_laptime,
      )
    self.camera.Update()
    self.text_gear.Update(self.car.engine.current_gear)
    self.text_speed.Update(self.car.speed)

  async def Run(self):
    menu = Menu(self.screen)
    team, driver, gear = await menu.run()
    if team is None:
      return
    await self._setup_race(team, driver, gear)
    while self.running:
      self.dt = self.clock.tick(FPS) / 1000.0
      self.Update()
      if not self.running:
        break
      self.Draw()
      await asyncio.sleep(0)

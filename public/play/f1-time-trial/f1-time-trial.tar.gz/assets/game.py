import asyncio
import sys

from settings import *
from world import World
from camera import Camera
from smallmap import SmallMap
from laptimer import LapTimer
from tracks import *
from textshower import Text
from menu import Menu
from touch_controls import TouchControls


class Game:
  def __init__(self):
    pygame.init()
    self.screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
    pygame.display.set_caption("F1 Time Trial")
    self.clock = pygame.time.Clock()
    self.running = True
    self.all_sprites = pygame.sprite.Group()
    self.obstacle_sprites = pygame.sprite.Group()
    self.drs_sprites = pygame.sprite.Group()
    self.ui_sprites = pygame.sprite.Group()
    self.menu = Menu(self.screen)
    self.touch = TouchControls()
    self.ready = False

  def _setup_race(self, team, driver, gear):
    self.gear = gear
    self.touch.set_manual_gears(gear == "manual")
    self.world = World("monza", self.all_sprites, self.obstacle_sprites, self.drs_sprites)
    for c in team.cars:
      if c.driver.name == driver.name:
        self.car = c
        break
    self.car.AddGroup(self.all_sprites, self.obstacle_sprites, self.drs_sprites)
    self.car.PartSetup("soft", 28, 25)
    self.car.AddGear(self.gear)
    self.camera = Camera(
      self.car,
      self.screen,
      len(self.world.track[0]) * TILE_SIZE,
      len(self.world.track) * TILE_SIZE,
    )
    self.smallmap = SmallMap("monza", self.car, self.ui_sprites, self.ui_sprites)
    self.laptimer = LapTimer(TRACK_CHECKPOINTS["monza"])
    # Keep HUD above on-screen touch pads on mobile / web
    hud_y = 430 if self.touch.enabled else 550
    self.text_gear = Text((650, hud_y), self.car.engine.current_gear, 40, WHITE)
    self.text_speed = Text((700, hud_y), self.car.speed, 40, WHITE)
    self.ready = True

  def HandleInput(self):
    for event in pygame.event.get():
      if event.type == pygame.QUIT:
        self.running = False
        return
      self.touch.handle_event(event)
      if event.type == pygame.KEYDOWN:
        if self.gear == "manual":
          if event.key == pygame.K_UP:
            self.car.engine.ShiftUp(self.car.speed)
          if event.key == pygame.K_DOWN:
            self.car.engine.ShiftDown(self.car.speed)

    taps = self.touch.consume_taps()
    if self.gear == "manual":
      if "gear_up" in taps:
        self.car.engine.ShiftUp(self.car.speed)
      if "gear_down" in taps:
        self.car.engine.ShiftDown(self.car.speed)

  def Draw(self):
    # Grass tiles are skipped as sprites; fill green as the track backdrop
    self.screen.fill(GREEN)
    self.camera.draw(self.all_sprites)
    self.camera.draw_ui(self.ui_sprites)
    self.laptimer.Draw(self.screen)
    for tc in TRACK_CHECKPOINTS["monza"]:
      pygame.draw.rect(self.screen, (255, 0, 0), tc, 0)
    self.text_gear.Draw(self.screen)
    self.text_speed.Draw(self.screen)
    self.touch.draw(self.screen)
    pygame.display.flip()

  def Update(self):
    self.HandleInput()
    if not self.running:
      return
    for sprite in self.all_sprites:
      if sprite is self.car:
        sprite.Update(self.touch)
      else:
        sprite.Update()
    for sprite in self.ui_sprites:
      sprite.Update()
    self.laptimer.Update(self.car, self.dt)
    self.camera.Update()
    self.text_gear.Update(self.car.engine.current_gear)
    self.text_speed.Update(self.car.speed)
    pygame.display.update()

  async def Run(self):
    team, driver, gear = await self.menu.run()
    if team is None:
      pygame.quit()
      return
    self._setup_race(team, driver, gear)
    while self.running:
      self.dt = self.clock.tick(FPS) / 1000.0
      self.Update()
      if not self.running:
        break
      self.Draw()
      await asyncio.sleep(0)
    pygame.quit()


# asyncio is used by Run(); import here so desktop + web both resolve it

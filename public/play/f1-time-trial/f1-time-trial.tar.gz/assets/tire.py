from settings import *

class Tire:
  def __init__(self, tire_type):
    self.tire_type = tire_type
    self.health = 100.0

    self.grip_base = TIRE_SPECS[self.tire_type]["grip"]
    self.wear_rate = TIRE_SPECS[self.tire_type]["wear"]
  def UpdateWear(self, speed, is_turning, tire_management_factor):
    if speed > 0:
      factor = TIRE_WEAR_TURNING_FACTOR if is_turning else TIRE_WEAR_STRAIGHT_FACTOR
      self.health -= speed * self.wear_rate * factor * tire_management_factor
      self.health = max(0.0, self.health)
  def get_current_grip(self):
    health_factor = self.health / 100.0
    if health_factor < TIRE_CLIFF_THRESHOLD:
      return self.grip_base * health_factor * TIRE_CLIFF_PENALTY_FACTOR
    return self.grip_base * health_factor

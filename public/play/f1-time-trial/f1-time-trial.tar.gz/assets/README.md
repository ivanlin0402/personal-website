# F1 Time Trial

Pygame time-trial racer based on V18 (choosable gear).

## Controls

### Keyboard
- **X** — accelerate
- **Z** — brake
- **Left / Right** — steer
- **Space** — open DRS (yellow track sections are DRS zones)
- **Up / Down** — shift gears (manual mode only)

### Phone / tablet (browser)
On-screen pads appear in the web build:
- **&lt; &gt;** — steer
- **GAS / BRK** — accelerate / brake
- **DRS** — open DRS in yellow zones
- **+ / −** — shift gears (manual mode only)

Multi-touch is supported so you can steer and accelerate at the same time.

Drive the **left** part of the Monza-style track.

## Requirements

- Python 3.10+
- pygame

```bash
pip install pygame
python main.py
```

## Menu

1. Choose a team  
2. Choose a driver  
3. Choose **Auto** or **Manual** gears  

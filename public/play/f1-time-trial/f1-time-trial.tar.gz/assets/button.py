from settings import *

from textshower import Text

class Button(pygame.sprite.Sprite):
  def __init__(self, name, pos, wh, word, size, color):
    super().__init__()
    self.name = name
    self.color = color
    self.pos = pos
    self.image = pygame.Surface(wh)
    self.image.fill(self.color)
    self.rect = self.image.get_rect(topleft=pos)
    centerx = pos[0] + wh[0]//2
    centery = pos[1] + wh[1]//2
    self.text = Text((centerx - (len(list(word)) * size // 4), centery - size // 2), word, size, BLACK)
    self.clicked = False
  def HandleInput(self, event):
    if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
      if self.rect.collidepoint(event.pos):
        self.clicked = True
    elif event.type == pygame.FINGERDOWN:
      pos = (event.x * WINDOW_WIDTH, event.y * WINDOW_HEIGHT)
      if self.rect.collidepoint(pos):
        self.clicked = True
  def Draw(self, screen):
    screen.blit(self.image, self.pos)
    self.text.Draw(screen)
    

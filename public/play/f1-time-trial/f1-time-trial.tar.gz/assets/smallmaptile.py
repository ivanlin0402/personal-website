from settings import *

class SmallMapTile(pygame.sprite.Sprite):
  def __init__(self, pos, tile_type, width, height, *groups):
    super().__init__(*groups)
    self.image = pygame.Surface((int(width), int(height)))
    if tile_type != "car":
      if tile_type == "grass":
        self.image.fill(GREEN)
      elif tile_type == "road":
        self.image.fill(GRAY)
      elif tile_type == "wall":
        self.image.fill(BLACK)
      elif tile_type == "drs":
        self.image.fill(YELLOW)
    else:
      self.image.fill(RED)
    self.rect = self.image.get_rect(topleft=(pos[0] + SMALLMAP_POS[0]+30, pos[1] + SMALLMAP_POS[1]+12))
  def UpdatePosition(self, new_pos):
    self.rect.topleft = (new_pos[0] + SMALLMAP_POS[0]+30, SMALLMAP_POS[1] + new_pos[1]+12)
  def Update(self):
    pass

import asyncio

from settings import *
from registry import RegistryINIT
from seasons import available_years
from button import Button
from assets_util import load_font


class Menu:
  def __init__(self, screen):
    self.screen = screen
    self.clock = pygame.time.Clock()
    self.chosen_year = False
    self.chosen_team = False
    self.chosen_driver = False
    self.chosen_gear = False
    self.year = None
    self.team = None
    self.driver = None
    self.gear = None
    self.quit = False
    self.ENGINE = None
    self.TEAM = None
    self.DRIVER = None
    self.team_buttons = []
    self.driver_buttons = []
    self.title_font = load_font(28)
    self.hint_font = load_font(16)
    self.year_buttons = self._build_year_buttons()
    self.gear_buttons = [
      Button("auto", (WINDOW_WIDTH / 3 - 100, WINDOW_HEIGHT / 2 - 25),
             (200, 50), "Auto", 20, (255, 0, 0)),
      Button("manual", (WINDOW_WIDTH * 2 / 3, WINDOW_HEIGHT / 2 - 25),
             (200, 50), "Manual", 20, (255, 0, 0)),
    ]

  def _build_year_buttons(self):
    buttons = []
    years = available_years()
    cols = 7
    width, height = 84, 40
    gap_x, gap_y = 16, 14
    grid_w = cols * width + (cols - 1) * gap_x
    start_x = (WINDOW_WIDTH - grid_w) // 2
    start_y = 86
    for i, year in enumerate(years):
      col = i % cols
      row = i // cols
      x = start_x + col * (width + gap_x)
      y = start_y + row * (height + gap_y)
      label = "'{:02d}".format(year % 100)
      buttons.append(Button(str(year), (x, y), (width, height), label, 18, (70, 130, 210)))
    return buttons

  def _load_year(self, year):
    self.year = int(year)
    self.ENGINE, self.TEAM, self.DRIVER = RegistryINIT(self.year)
    self.team_buttons = []
    teams = self.TEAM.TEAMS
    cols = 2
    width, height = 220, 42
    gap_x, gap_y = 24, 12
    grid_w = cols * width + (cols - 1) * gap_x
    start_x = (WINDOW_WIDTH - grid_w) // 2
    start_y = 86
    for i, team in enumerate(teams):
      col = i % cols
      row = i // cols
      x = start_x + col * (width + gap_x)
      y = start_y + row * (height + gap_y)
      self.team_buttons.append(
        Button(team.name, (x, y), (width, height), team.short_name, 16, team.color)
      )
    self.driver_buttons = []

  def _current_buttons(self):
    if not self.chosen_year:
      return self.year_buttons
    if not self.chosen_team:
      return self.team_buttons
    if not self.chosen_driver:
      if not self.driver_buttons and self.team is not None:
        d1, d2 = self.team.drivers[0], self.team.drivers[1]
        self.driver_buttons = [
          Button(
            d1.name,
            (WINDOW_WIDTH / 3 - 120, WINDOW_HEIGHT / 2 - 25),
            (240, 54),
            "{}  {}".format(d1.name, d1.pace),
            14,
            (255, 80, 80),
          ),
          Button(
            d2.name,
            (WINDOW_WIDTH * 2 / 3 - 20, WINDOW_HEIGHT / 2 - 25),
            (240, 54),
            "{}  {}".format(d2.name, d2.pace),
            14,
            (255, 80, 80),
          ),
        ]
      return self.driver_buttons
    return self.gear_buttons

  def _heading(self):
    if not self.chosen_year:
      return "SELECT YEAR", "'88 to '25"
    if not self.chosen_team:
      return "SELECT TEAM", str(self.year)
    if not self.chosen_driver:
      return "SELECT DRIVER", "{}  {}".format(self.year, self.team.name)
    return "SELECT GEAR", "{}  {}  {}".format(self.year, self.team.short_name, self.driver.name)

  def _apply_clicks(self, buttons):
    if not self.chosen_year:
      for b in buttons:
        if b.clicked:
          self._load_year(int(b.name))
          self.chosen_year = True
          b.clicked = False
          return
    elif not self.chosen_team:
      for b in buttons:
        if b.clicked:
          for t in self.TEAM.TEAMS:
            if t.name == b.name:
              self.team = t
          self.chosen_team = True
          b.clicked = False
          return
    elif not self.chosen_driver:
      for b in buttons:
        if b.clicked:
          for d in self.team.drivers:
            if d.name == b.name:
              self.driver = d
          self.chosen_driver = True
          b.clicked = False
          return
    else:
      for b in buttons:
        if b.clicked:
          self.gear = b.name
          self.chosen_gear = True
          b.clicked = False
          return

  def _draw_heading(self):
    title, subtitle = self._heading()
    title_surf = self.title_font.render(title, True, WHITE)
    sub_surf = self.hint_font.render(subtitle, True, (170, 170, 170))
    self.screen.blit(title_surf, (WINDOW_WIDTH // 2 - title_surf.get_width() // 2, 22))
    self.screen.blit(sub_surf, (WINDOW_WIDTH // 2 - sub_surf.get_width() // 2, 54))

  async def run(self):
    print("menu async loop start")
    while not (self.chosen_year and self.chosen_team and self.chosen_driver and self.chosen_gear):
      self.clock.tick(FPS)
      buttons = self._current_buttons()

      for event in pygame.event.get():
        if event.type == pygame.QUIT:
          self.quit = True
          return None, None, None
        for b in buttons:
          b.HandleInput(event)

      self.screen.fill(BLACK)
      self._draw_heading()
      for b in buttons:
        b.Draw(self.screen)
      self._apply_clicks(buttons)
      pygame.display.flip()
      await asyncio.sleep(0)

    print("menu done", self.year, self.team.name, self.driver.name, self.gear)
    return self.team, self.driver, self.gear

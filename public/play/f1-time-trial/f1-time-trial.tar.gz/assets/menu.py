import asyncio

from settings import *
from registry import RegistryINIT
from button import Button


class Menu:
  def __init__(self, screen):
    self.ENGINE, self.TEAM, self.DRIVER = RegistryINIT()
    self.screen = screen
    self.clock = pygame.time.Clock()
    self.chosen_team = False
    self.chosen_driver = False
    self.chosen_gear = False
    self.team = ""
    self.driver = ""
    self.gear = ""
    self.quit = False

    self.team_buttons = [
      Button("Red Bull Racing", (WINDOW_WIDTH // 4 - 100, WINDOW_HEIGHT // 2 - 50),
             (200, 50), "Red Bull", 20, (0, 0, 255)),
      Button("Ferrari", (WINDOW_WIDTH // 2 - 100, WINDOW_HEIGHT // 2 - 50),
             (200, 50), "Ferrari", 20, (255, 0, 0)),
      Button("Mercedes", (WINDOW_WIDTH * 3 // 4 - 100, WINDOW_HEIGHT // 2 - 50),
             (200, 50), "Mercedes", 20, (50, 50, 50)),
      Button("McLaren", (WINDOW_WIDTH // 4 - 100, WINDOW_HEIGHT // 2),
             (200, 50), "McLaren", 20, (255, 100, 0)),
      Button("Audi", (WINDOW_WIDTH // 2 - 100, WINDOW_HEIGHT // 2),
             (200, 50), "Audi", 20, (200, 200, 200)),
      Button("Haas", (WINDOW_WIDTH * 3 // 4 - 100, WINDOW_HEIGHT // 2),
             (200, 50), "Haas", 20, (255, 255, 255)),
      Button("Williams", (WINDOW_WIDTH // 4 - 100, WINDOW_HEIGHT // 2 + 50),
             (200, 50), "Williams", 20, (100, 0, 255)),
      Button("Alpine", (WINDOW_WIDTH // 2 - 100, WINDOW_HEIGHT // 2 + 50),
             (200, 50), "Alpine", 20, (255, 0, 255)),
      Button("Aston Martin", (WINDOW_WIDTH * 3 // 4 - 100, WINDOW_HEIGHT // 2 + 50),
             (200, 50), "Aston Martin", 20, (0, 150, 0)),
      Button("Racing Bulls", (WINDOW_WIDTH // 2 - 100, WINDOW_HEIGHT // 2 + 100),
             (200, 50), "Racing Bulls", 20, (0, 255, 255)),
    ]
    self.driver_buttons = []
    self.gear_buttons = [
      Button("auto", (WINDOW_WIDTH / 3 - 100, WINDOW_HEIGHT / 2 - 25),
             (200, 50), "Auto", 20, (255, 0, 0)),
      Button("manual", (WINDOW_WIDTH * 2 / 3, WINDOW_HEIGHT / 2 - 25),
             (200, 50), "Manual", 20, (255, 0, 0)),
    ]

  async def run(self):
    while not (self.chosen_team and self.chosen_driver and self.chosen_gear):
      self.clock.tick(FPS)

      if not self.chosen_team:
        buttons = self.team_buttons
      elif not self.chosen_driver:
        if not self.driver_buttons:
          driver_1_name = self.team.drivers[0].name
          driver_2_name = self.team.drivers[1].name
          button_driver_01 = Button(
            driver_1_name,
            (WINDOW_WIDTH / 3 - 100, WINDOW_HEIGHT / 2 - 25),
            (200, 50),
            self.team.drivers[0].name,
            15,
            (255, 0, 0),
          )
          button_driver_02 = Button(
            driver_2_name,
            (WINDOW_WIDTH * 2 / 3, WINDOW_HEIGHT / 2 - 25),
            (200, 50),
            self.team.drivers[1].name,
            15,
            (255, 0, 0),
          )
          self.driver_buttons = [button_driver_01, button_driver_02]
        buttons = self.driver_buttons
      else:
        buttons = self.gear_buttons

      for event in pygame.event.get():
        if event.type == pygame.QUIT:
          self.quit = True
          return None, None, None
        for b in buttons:
          b.HandleInput(event)

      self.screen.fill(BLACK)
      for b in buttons:
        b.Draw(self.screen)

      if self.chosen_team is False:
        for b in buttons:
          if b.clicked:
            for t in self.TEAM.TEAMS:
              if t.name == b.name:
                self.team = t
            self.chosen_team = True
            b.clicked = False
      elif self.chosen_driver is False:
        for b in buttons:
          if b.clicked:
            for d in self.DRIVER.DRIVERS:
              if d.name == b.name:
                self.driver = d
            self.chosen_driver = True
            b.clicked = False
      elif self.chosen_gear is False:
        for b in buttons:
          if b.clicked:
            self.gear = b.name
            self.chosen_gear = True
            b.clicked = False

      pygame.display.flip()
      await asyncio.sleep(0)

    return self.team, self.driver, self.gear

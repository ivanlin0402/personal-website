import asyncio

from settings import *
from registry import RegistryINIT
from button import Button


class Menu:
  def __init__(self, screen):
    self.ENGINE, self.TEAM, self.DRIVER = RegistryINIT()
    self.screen = screen
    self.clock = pygame.time.Clock()
    self.chosen_team = False
    self.chosen_driver = False
    self.chosen_gear = False
    self.team = None
    self.driver = None
    self.gear = None
    self.quit = False
    self.driver_buttons = []

    self.team_buttons = [
      Button("Red Bull Racing", (WINDOW_WIDTH // 4 - 100, WINDOW_HEIGHT // 2 - 50),
             (200, 50), "Red Bull", 20, (0, 0, 255)),
      Button("Ferrari", (WINDOW_WIDTH // 2 - 100, WINDOW_HEIGHT // 2 - 50),
             (200, 50), "Ferrari", 20, (255, 0, 0)),
      Button("Mercedes", (WINDOW_WIDTH * 3 // 4 - 100, WINDOW_HEIGHT // 2 - 50),
             (200, 50), "Mercedes", 20, (50, 50, 50)),
      Button("McLaren", (WINDOW_WIDTH // 4 - 100, WINDOW_HEIGHT // 2),
             (200, 50), "McLaren", 20, (255, 100, 0)),
      Button("Audi", (WINDOW_WIDTH // 2 - 100, WINDOW_HEIGHT // 2),
             (200, 50), "Audi", 20, (200, 200, 200)),
      Button("Haas", (WINDOW_WIDTH * 3 // 4 - 100, WINDOW_HEIGHT // 2),
             (200, 50), "Haas", 20, (255, 255, 255)),
      Button("Williams", (WINDOW_WIDTH // 4 - 100, WINDOW_HEIGHT // 2 + 50),
             (200, 50), "Williams", 20, (100, 0, 255)),
      Button("Alpine", (WINDOW_WIDTH // 2 - 100, WINDOW_HEIGHT // 2 + 50),
             (200, 50), "Alpine", 20, (255, 0, 255)),
      Button("Aston Martin", (WINDOW_WIDTH * 3 // 4 - 100, WINDOW_HEIGHT // 2 + 50),
             (200, 50), "Aston Martin", 20, (0, 150, 0)),
      Button("Racing Bulls", (WINDOW_WIDTH // 2 - 100, WINDOW_HEIGHT // 2 + 100),
             (200, 50), "Racing Bulls", 20, (0, 255, 255)),
    ]
    self.gear_buttons = [
      Button("auto", (WINDOW_WIDTH / 3 - 100, WINDOW_HEIGHT / 2 - 25),
             (200, 50), "Auto", 20, (255, 0, 0)),
      Button("manual", (WINDOW_WIDTH * 2 / 3, WINDOW_HEIGHT / 2 - 25),
             (200, 50), "Manual", 20, (255, 0, 0)),
    ]

  def _current_buttons(self):
    if not self.chosen_team:
      return self.team_buttons
    if not self.chosen_driver:
      if not self.driver_buttons:
        self.driver_buttons = [
          Button(
            self.team.drivers[0].name,
            (WINDOW_WIDTH / 3 - 100, WINDOW_HEIGHT / 2 - 25),
            (200, 50),
            self.team.drivers[0].name,
            15,
            (255, 0, 0),
          ),
          Button(
            self.team.drivers[1].name,
            (WINDOW_WIDTH * 2 / 3, WINDOW_HEIGHT / 2 - 25),
            (200, 50),
            self.team.drivers[1].name,
            15,
            (255, 0, 0),
          ),
        ]
      return self.driver_buttons
    return self.gear_buttons

  def _apply_clicks(self, buttons):
    if not self.chosen_team:
      for b in buttons:
        if b.clicked:
          for t in self.TEAM.TEAMS:
            if t.name == b.name:
              self.team = t
          self.chosen_team = True
          b.clicked = False
          return
    elif not self.chosen_driver:
      for b in buttons:
        if b.clicked:
          for d in self.team.drivers:
            if d.name == b.name:
              self.driver = d
          self.chosen_driver = True
          b.clicked = False
          return
    else:
      for b in buttons:
        if b.clicked:
          self.gear = b.name
          self.chosen_gear = True
          b.clicked = False
          return

  async def run(self):
    print("menu async loop start")
    while not (self.chosen_team and self.chosen_driver and self.chosen_gear):
      self.clock.tick(FPS)
      buttons = self._current_buttons()

      for event in pygame.event.get():
        if event.type == pygame.QUIT:
          self.quit = True
          return None, None, None
        for b in buttons:
          b.HandleInput(event)

      self.screen.fill(BLACK)
      for b in buttons:
        b.Draw(self.screen)
      self._apply_clicks(buttons)
      pygame.display.flip()
      await asyncio.sleep(0)

    print("menu done", self.team.name, self.driver.name, self.gear)
    return self.team, self.driver, self.gear

from settings import *
from assets_util import load_font

class LapTimer:
  def __init__(self, checkpoints):
    self.checkpoints = checkpoints
    self.total_checkpoints = len(self.checkpoints)

    self.current_laptime = 0.0
    self.last_laptime = float("inf")
    self.best_laptime = float("inf")
    
    self.current_checkpoint_index = 0
    self.lap_count = 0
    self.has_started = False

    self.best_lap_sector_times = {}
    self.current_sector_times = {}
    self.delta_time = 0.0
    self.delta_color = WHITE

    self.delta_display_timer = 0.0
    self.show_delta = False

    if not pygame.font.get_init():
      pygame.font.init()
    self.font = load_font(20)
    try:
      self.font.set_bold(True)
    except Exception:
      pass
    
  def Update(self, car, dt):
    lap_just_finished = False

    if self.has_started:
      self.current_laptime += dt
    if self.show_delta:
      self.delta_display_timer -= dt
      '''
      if self.delta_display_timer <= 0:
        self.show_delta = False
        '''
    if not self.has_started:
      self.current_checkpoint_index = self.total_checkpoints - 1
    target_cp = self.checkpoints[self.current_checkpoint_index]
    if car.rect.colliderect(target_cp):
      self.current_sector_times[self.current_checkpoint_index] = self.current_laptime
      if self.current_checkpoint_index in self.best_lap_sector_times:
        self.show_delta = True
        self.delta_time = self.current_laptime - self.best_lap_sector_times[self.current_checkpoint_index]
        if self.delta_time <= 0:
          self.delta_color = LAPTIME_GREEN
        else:
          self.delta_color = (255, 255, 0)
      if self.current_checkpoint_index == (self.total_checkpoints - 1):
        if not self.has_started:
          self.has_started = True
          self.current_laptime = 0.0
          self.lap_count = 1
          self.current_checkpoint_index = 0
        else:
          self.last_laptime = self.current_laptime
          lap_just_finished = True
          self.lap_count += 1
          if self.last_laptime < self.best_laptime:
            self.best_laptime = self.last_laptime
            self.best_lap_sector_times = self.current_sector_times.copy()
          self.current_laptime = 0.0
          self.current_checkpoint_index = 0
          self.current_sector_times = {}
          self.delta_time = 0.0
          self.delta_color = WHITE
      else:
        self.current_checkpoint_index += 1

    return lap_just_finished
  def FormatTime(self, seconds):
    if seconds == float("inf"):
      return "--:--.---"
    mins = int(seconds // 60)
    secs = int(seconds % 60)
    millisecs = int((seconds - int(seconds)) * 1000)
    return "{:01d}:{:02d}.{:03d}" . format(mins, secs, millisecs)
  def FormatDelta(self):
    if not self.best_lap_sector_times or self.delta_time == 0.0:
      return ""
    if self.delta_time > 0:
      sign = "+"
    else:
      sign = "-"
    return "{}{:.3f}" . format(sign, abs(self.delta_time))
  def Draw(self, screen):
    lap_str = "LAP: {}" . format(self.lap_count if self.has_started else 0)
    curr_str = "TIME: {}" . format(self.FormatTime(self.current_laptime))
    best_str = "BEST: {}" . format(self.FormatTime(self.best_laptime))
    last_str = "LAST: {}" . format(self.FormatTime(self.last_laptime))

    lap_text = self.font.render(lap_str, True, (255, 255, 255))
    curr_text = self.font.render(curr_str, True, (255, 255, 255))
    best_text = self.font.render(best_str, True, (255, 215, 0))
    last_text = self.font.render(last_str, True, (200, 200, 200))

    screen.blit(lap_text, (20, 20))
    screen.blit(curr_text, (20, 55))
    screen.blit(best_text, (20, 90))
    screen.blit(last_text, (20, 125))
    if self.show_delta:
      sign = "+" if self.delta_time > 0 else "-"
      delta_str = "DELTA: {}{:.3f}" . format(sign, abs(self.delta_time))
      delta_text = self.font.render(delta_str, True, self.delta_color)
      screen.blit(delta_text, (20, 160))
